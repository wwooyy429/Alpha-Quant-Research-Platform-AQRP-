import os,sys,json
from pathlib import Path
from aqrp.backtest.synthetic import fixture_request
import aqrp.services.backtest as service
from aqrp.backtest.engine import Simulator
class CrashSimulator(Simulator):
 def __init__(self,config,root,commit):
  def fault(stage):
   if stage!=sys.argv[2]: return
   paths=list((root/'transactions').glob('prepared-*.json' if stage=='BEFORE_COMMIT' else 'commit-*.json'))
   if paths:
    x=json.loads(max(paths,key=lambda p:p.stat().st_mtime_ns).read_bytes())
    if any(v['kind']=='Fill' for v in x['children']):os._exit(71)
  super().__init__(config,root,commit,fault=fault)
service.Simulator=CrashSimulator
service.simulate_engineering(fixture_request(),Path(sys.argv[1]),sys.argv[3])
