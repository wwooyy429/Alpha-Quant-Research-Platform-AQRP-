import os,sys,json,pathlib,hashlib,shutil,datetime,re,xml.etree.ElementTree as ET
from fractions import Fraction
B=pathlib.Path(r'C:/Users/11638/AppData/Local/AQRP/reviews');O=B/'windows-isolation-9ac5db0-r2-e6968f1c-review';P=B/'windows-isolation-9ac5db0-continuation2';R=P/'results/e6968f1c-3552-4a98-af61-98a5194dafea';T=pathlib.Path(r'C:/AQRP-Sealed/verify-9ac5db0')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(v):return hashlib.sha256(canon(v)).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
copies=[]
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);copies.append({'source':str(src),'copy':dst.relative_to(O).as_posix(),'sha256':sha(dst),'bytes':dst.stat().st_size})
for p in sorted(R.iterdir()):
 if p.is_file():cp(p,O/'raw-admin'/p.name)
state=read(R/'final-state.json');procs=read(R/'process-results.json');acl=read(R/'acl-after-dynamic-files.json');ns='engineering-r2-'+state['attempt_id'];work=T/'sealed/work'/ns;control=T/'sealed/control'/ns
summary=[];failures=[]
for p in procs:
 result=p.get('result') or {};checks=result.get('checks') or []
 # Compare persisted process result with its independent raw stdout JSON.
 if checks or result:
  raw=read(R/(p['label']+'.stdout.log'));assert result==raw
  assert result['actual_sid']==p['expected_sid'];assert not result['native_token']['elevated']
 assert p['identity_evidence_valid'] and p['expected_exit']
 fs=[c for c in checks if not c['pass_']];failures.extend({'process':p['label'],**c} for c in fs)
 summary.append({'label':p['label'],'role':p['role'],'exit_code':p['exit_code'],'identity_valid':p['identity_evidence_valid'],'checks':len(checks),'passed':sum(c['pass_'] for c in checks),'failed':len(fs)})
assert sum(x['checks'] for x in summary)==184 and len(failures)==1
assert failures[0]['name']=='operator_policy_verify_host_after_dynamic_engineering_files'
clixml=[]
for p in R.glob('*.stderr.log'):
 s=p.read_text(encoding='utf-8-sig')
 if '<Objs' in s:
  groups=re.findall(r'<Objs\b.*?</Objs>',s,re.S);categories=[]
  for group in groups:
   categories.extend(e.attrib['S'] for e in ET.fromstring(group).iter() if 'S' in e.attrib)
  assert groups and categories and set(categories)=={'progress'}
  clixml.append({'path':p.name,'xml_documents':len(groups),'categories':sorted(set(categories)),'raw_preserved':True})
sealed=[x for x in acl if pathlib.Path(x['path']).is_relative_to(T/'sealed')]
inherited=[x for x in sealed if not x['protected']];owner_rights=[x for x in sealed if ';;;OW)' in x['sddl']]
assert len(inherited)==42 and len(owner_rights)==10
save('ACL_INCOMPATIBILITIES.json',{'unprotected_count':42,'unprotected':inherited,'owner_rights_count':10,'owner_rights':owner_rights,'qualification':'Metadata replay of fixed evaluator.py protected/allowed-SID predicates, not a new actual-token access test.'})
# Collect all reachable engineering output. Explicitly retain permission errors and ACL-listed omissions.
walk_errors=[]
for root in [work,control]:
 for parent,dirs,files in os.walk(root,onerror=lambda e:walk_errors.append({'path':e.filename,'errno':e.errno,'winerror':getattr(e,'winerror',None),'type':type(e).__name__})):
  for f in files:
   p=pathlib.Path(parent)/f
   try:cp(p,O/'engineering-artifacts'/p.relative_to(T/'sealed'))
   except PermissionError as e:walk_errors.append({'path':str(p),'errno':e.errno,'type':type(e).__name__})
blocked_snapshot=[x for x in owner_rights if 'snapshot' in x['path']]
save('OMISSIONS.json',{'errors':walk_errors,'snapshot_acl_rows':blocked_snapshot,'snapshot_objects':len(blocked_snapshot),'snapshot_files_not_copied_or_rehashed':9,'snapshot_manifest_hash_independently_verified':False,'actual_auditor_probe_on_generated_snapshot':'NOT VERIFIED','no_acl_or_owner_change_attempted':True})
assert len(blocked_snapshot)==10 and walk_errors
# Canonical hash chains, without importing or calling AQRP code.
chains=[]
for name,expected in [('demo-race',['RESERVED','SUCCEEDED']+['REJECTED_REPEAT']*5),('demo-crash',['RESERVED','FAILED_CONSUMED','REJECTED_REPEAT'])]:
 p=control/name/'access.jsonl';rows=[json.loads(l) for l in p.read_text().splitlines()];prev='0'*64
 for i,row in enumerate(rows):
  content={k:v for k,v in row.items() if k!='hash'};assert row['seq']==i and row['previous']==prev and digest(content)==row['hash'];prev=row['hash']
 assert [x['kind'] for x in rows]==expected
 chains.append({'path':str(p),'records':len(rows),'kinds':expected,'last_hash':prev,'verified':True})
assert not (control/'demo-abort/access.jsonl').exists()
# Exact-rational independent QA; compare persisted actual factor rows and every member hash.
golden={'momentum':Fraction(121,100)-1,'reversal':-(Fraction(121,100)-1),'volume':Fraction(200,1)/((Fraction(100)+150)/2)-1};golden['price_volume']=(Fraction(121,110)-1)*golden['volume'];factor=[]
actor=read(R/'evaluator-inspect.stdout.log')['actual_engineering_factor_execution']
for m in sorted((work/'engineering-factor-run/factor-runs').glob('*/manifest.json')):
 d=read(m);rows=read(m.parent/'signals.json');config=read(m.parent/'config.json');assert len(rows)==1;row=rows[0];fid=row['factor_id'];expected=golden[fid]
 assert abs(Fraction(str(row['factor_value']))-expected)<=Fraction(1,10**12)
 assert row['factor_value']==actor['values'][fid]['value']
 for member in d['artifacts']:assert sha(m.parent/member['path'])==member['sha256']
 logical=digest([{k:v for k,v in r.items() if k not in {'snapshot_id','run_id','computation_id'}} for r in rows]);content=digest({'rows':rows,'config':canon(config).decode()})
 assert logical==d['logical_hash']==actor['values'][fid]['logical_hash'];assert content==d['content_hash'];assert d['mode']=='TEST_ONLY' and d['financial_approval']=='NONE'
 factor.append({'factor':fid,'expected_rational':str(expected),'actual':row['factor_value'],'absolute_tolerance':'1e-12','member_hashes':True,'logical_hash':logical,'content_hash':content,'manifest':str(m)})
assert len(factor)==4
# Both complete runtimes rehashed against original frozen payload; no source import/execution.
payload=read(B/'windows-isolation-9ac5db0/PAYLOAD_MANIFEST.json');entries=[x for x in payload['files'] if x['path'].startswith('runtime/')];integrity=[]
assert len(entries)==6250
for name in ['runtime_eval','runtime_public']:
 for e in entries:
  p=T/name/e['path'][8:];assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],str(p)
 package=T/name/'Lib/site-packages/aqrp';files=[{'path':p.relative_to(package).as_posix(),'sha256':sha(p)} for p in sorted(package.rglob('*.py'))];bundle=digest({'factor_api':'1.0.0','data_contract':'contracts/1.0.0','dependency_lock_sha256':'86c7bf65c9a9690036006360062c8cd10a91279705b4070af7033d7699abffeb','files':files})
 assert len(files)==45 and bundle==payload['bundle_hash'];integrity.append({'runtime':name,'files_verified':6250,'business_modules':45,'bundle_hash':bundle})
before=read(R/'acl-before-principals.json'); amap={x['path']:x for x in acl}; assert len(before)==1313 and all(amap[x['path']]==x for x in before)
crash=read(R/'evaluator-crash.stderr.log'); assert crash['native_token']['sid']==state['accounts'][1]['sid'] and not crash['native_token']['elevated']
prep=read(P/'PREPARATION_MANIFEST.json');bindings=[]
for e in prep['deploy_files']:
 p=P/e['path'];assert sha(p)==e['sha256'];cp(p,O/'reviewed-harness'/p.name);bindings.append({'file':str(p),'sha256':sha(p)})
assert sha(T/'entry/worker-r2.py')==state['worker_sha256']==prep['deploy_files'][0]['sha256']
assert sha(pathlib.Path(state['config_path']))==state['config_sha256'];cp(pathlib.Path(state['config_path']),O/'reviewed-harness'/pathlib.Path(state['config_path']).name)
for n in ['PREPARATION_MANIFEST.json','PREPARATION_RECEIPT.json']:cp(P/n,O/'reviewed-harness'/n)
cp(B/'windows-isolation-9ac5db0/PAYLOAD_MANIFEST.json',O/'reviewed-harness/PAYLOAD_MANIFEST.json')
assert sha(T/'entry/worker.py')==prep['original_worker_sha256'];assert read(T/'DEPLOYMENT_STATE.json')==read(R/'original-failed-state.json')
for rel in ['validation/evaluator.py','experiments/ledger.py','data/snapshot.py','factors/admission.py','factors/contracts.py','factors/engine.py','core/canonical.py']:
 cp(T/'runtime_eval/Lib/site-packages/aqrp'/rel,O/'fixed-source/aqrp'/rel)
cp(T/'runtime_eval/Lib/tempfile.py',O/'fixed-source/stdlib/tempfile.py')
accounts=read(O/'current-accounts.json');assert len(accounts)==3 and all(not x['enabled'] for x in accounts)
result={'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_python':sys.version,'review_platform':sys.platform,'fixed_sha':state['fixed_sha'],'attempt_id':state['attempt_id'],'admin_run_status':state['status'],'processes':summary,'check_count':184,'passed':183,'failed':1,'failures':failures,'clixml':clixml,'chains':chains,'independent_exact_rational_factors':factor,'runtime_integrity':integrity,'harness_bindings':bindings,'accounts_currently_disabled':True,'original_state_and_worker_unchanged':True,'raw_admin_files':len(list(R.iterdir())),'no_account_acl_or_business_changes_by_review':True,'whole_windows_profile':'NOT VERIFIED / BLOCKED','formal_test':'NOT EXECUTED / NOT AUTHORIZED','financial_approval':'NONE','full_historical_host_reproduction':'NOT VERIFIED'}
save('COPIED_FILES.json',copies);save('INDEPENDENT_VERIFICATION.json',result)
print(json.dumps({'processes':len(summary),'checks':184,'passed':183,'failed':1,'runtime_files_rehashed_each':6250,'raw_admin_files':result['raw_admin_files'],'copied_files':len(copies),'snapshot_omissions':9,'golden_factors':len(factor),'accounts_disabled':True},ensure_ascii=False))

