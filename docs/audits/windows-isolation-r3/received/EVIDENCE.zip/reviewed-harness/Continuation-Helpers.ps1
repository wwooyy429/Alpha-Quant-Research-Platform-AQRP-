﻿function Write-Json([string]$Path,$Object) { [IO.File]::WriteAllText($Path,($Object|ConvertTo-Json -Depth 40),$Utf8) }

function Assert-Root([string]$Path) {
 $resolved=[IO.Path]::GetFullPath($Path).TrimEnd('\')
 if($resolved -ne $TargetRoot -and -not $resolved.StartsWith($TargetRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'PATH_OUTSIDE_AUTHORIZED_ROOT'}
 $walk=$resolved
 while($walk) {
  $p=Get-Item -LiteralPath $walk -Force -ErrorAction SilentlyContinue
  if($p -and ($p.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'REPARSE_POINT_REFUSED'}
  $walk=[IO.Path]::GetDirectoryName($walk)
 }
 return $resolved
}

function Require-Admin {
 if(-not [Environment]::Is64BitProcess){throw '64_BIT_WINDOWS_POWERSHELL_REQUIRED'}
 if($PSVersionTable.PSEdition -ne 'Desktop'){throw 'USE_WINDOWS_POWERSHELL_5_1_FOR_ADMIN_SCRIPT'}
 if($CurrentIdentity.User.Value -ne $ExpectedOwner){throw 'WRONG_TRUSTED_OWNER_SID'}
 if(-not $CurrentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'ADMINISTRATOR_WINDOW_REQUIRED'}
}

function New-Password {
 $bytes=New-Object byte[] 30
 $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
 try {$rng.GetBytes($bytes)} finally {$rng.Dispose()}
 $password=ConvertTo-SecureString ('Aq9!'+[Convert]::ToBase64String($bytes)) -AsPlainText -Force
 [Array]::Clear($bytes,0,$bytes.Length)
 return $password
}

function Set-ExactAcl([string]$Path,[hashtable]$Extra,[switch]$SelfOnly) {
 $Path=Assert-Root $Path
 $item=Get-Item -LiteralPath $Path -Force
 if($item.PSIsContainer){$acl=[Security.AccessControl.DirectorySecurity]::new()}
 else {$acl=[Security.AccessControl.FileSecurity]::new()}
 $acl.SetOwner([Security.Principal.SecurityIdentifier]::new($ExpectedOwner))
 $acl.SetAccessRuleProtection($true,$false)
 $rules=@{$ExpectedOwner='FullControl';'S-1-5-18'='FullControl';'S-1-5-32-544'='FullControl'}
 foreach($sid in $Extra.Keys){$rules[$sid]=$Extra[$sid]}
 foreach($sid in $rules.Keys){
  $inherit=[Security.AccessControl.InheritanceFlags]::None
  if($item.PSIsContainer){$inherit=[Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'}; if($SelfOnly -and $Extra.ContainsKey($sid)){$inherit=[Security.AccessControl.InheritanceFlags]::None}
  $rule=[Security.AccessControl.FileSystemAccessRule]::new(
   [Security.Principal.SecurityIdentifier]::new($sid),
   [Security.AccessControl.FileSystemRights]$rules[$sid],$inherit,
   [Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow)
  [void]$acl.AddAccessRule($rule)
 }
 $item.SetAccessControl($acl)
}

function Set-TreeAcl([string]$Path,[hashtable]$Extra) {
 Set-ExactAcl $Path $Extra
 foreach($item in @(Get-ChildItem -LiteralPath $Path -Recurse -Force)){Set-ExactAcl $item.FullName $Extra}
}

function Check-Payload {
 $manifest=Get-Content -LiteralPath (Join-Path $PackageRoot 'PAYLOAD_MANIFEST.json') -Raw | ConvertFrom-Json
 if($manifest.reviewed_sha -ne $FixedSha){throw 'PAYLOAD_SHA_MISMATCH'}
 $payload=Join-Path $PackageRoot 'payload'
 $actualFiles=@(Get-ChildItem -LiteralPath $payload -Recurse -File -Force)
 if($actualFiles.Count -ne @($manifest.files).Count){throw 'PAYLOAD_FILE_SET_MISMATCH'}
 foreach($row in $manifest.files){
  $path=[IO.Path]::GetFullPath((Join-Path $payload $row.path))
  if(-not $path.StartsWith(([IO.Path]::GetFullPath($payload)+'\'),[StringComparison]::OrdinalIgnoreCase)){throw 'PAYLOAD_PATH_ESCAPE'}
  $item=Get-Item -LiteralPath $path -Force
  if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'LINK_IN_PAYLOAD'}
  if($item.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $row.sha256){throw "PAYLOAD_FILE_HASH_MISMATCH: $($row.path)"}
 }
 return $manifest
}

function Start-Role([string]$Role,[string]$Action,[string]$Label) {
 if($Role -notin @('research','evaluator','auditor') -or $Action -notin @('inspect','post-inspect','race','crash','recover','after','abort-before','alias')){throw 'ENTRY_ARGUMENT_NOT_ALLOWED'}
 $runtime=if($Role -eq 'evaluator'){'runtime_eval'}else{'runtime_public'}
 $start=[Diagnostics.ProcessStartInfo]::new()
 $start.FileName=Join-Path $TargetRoot ($runtime+'\python.exe')
 $start.Arguments='-B -I "'+$WorkerPath+'" '+$Role+' '+$Action+' "'+$ConfigPath+'"'
 $start.WorkingDirectory=Join-Path $TargetRoot ('scratch\'+$Role)
 $start.UseShellExecute=$false
 $start.CreateNoWindow=$true
 $start.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
 $start.LoadUserProfile=$false
 $start.RedirectStandardOutput=$true
 $start.RedirectStandardError=$true
 $start.UserName=$LocalNames[$Role]
 $start.Domain=$env:COMPUTERNAME
 $start.Password=$Passwords[$Role]
 $start.EnvironmentVariables.Clear()
 foreach($key in @('SystemRoot','WINDIR')){$start.EnvironmentVariables[$key]=$env:SystemRoot}
 $start.EnvironmentVariables['PATH']=$env:SystemRoot+'\System32;'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
 $start.EnvironmentVariables['TEMP']=$start.WorkingDirectory
 $start.EnvironmentVariables['TMP']=$start.WorkingDirectory
 $start.EnvironmentVariables['COMPUTERNAME']=$env:COMPUTERNAME
 $process=[Diagnostics.Process]::new();$process.StartInfo=$start
 [void]$process.Start();$Processes.Add($process)
 # Async drain prevents pipe deadlock even when ACL test output is large.
 return @{process=$process;stdout=$process.StandardOutput.ReadToEndAsync();stderr=$process.StandardError.ReadToEndAsync();role=$Role;action=$Action;label=$Label;argv=@($start.FileName,$start.Arguments);start_utc=[DateTime]::UtcNow.ToString('o')}
}

function Complete-Role($Job,[int[]]$Allowed=@(0)) {
 $p=$Job.process
 if(-not $p.WaitForExit(240000)){try{$p.Kill();$p.WaitForExit()}catch{};throw ('CHILD_TIMEOUT: '+$Job.label)}
 $stdout=$Job.stdout.Result;$stderr=$Job.stderr.Result
 $record=@{role=$Job.role;mode=$Job.action;label=$Job.label;argv=$Job.argv;expected_sid=$ExpectedSids[$Job.role];started_utc=$Job.start_utc;ended_utc=[DateTime]::UtcNow.ToString('o');exit_code=$p.ExitCode;expected_exit_codes=$Allowed}
 [IO.File]::WriteAllText((Join-Path $ExportPath ($Job.label+'.stdout.log')),$stdout,$Utf8)
 [IO.File]::WriteAllText((Join-Path $ExportPath ($Job.label+'.stderr.log')),$stderr,$Utf8)
 $record.expected_exit=($p.ExitCode -in $Allowed)
 $record.identity_evidence_valid=$false
 if($Job.action -eq 'crash' -and $p.ExitCode -eq 23){
  try{$trace=$stderr.Trim()|ConvertFrom-Json;$record.crash_trace=$trace;$record.identity_evidence_valid=($trace.event -eq 'ENGINEERING_CRASH_BEFORE_RESULT' -and $trace.native_token.sid -eq $ExpectedSids[$Job.role] -and -not $trace.native_token.elevated -and $trace.attempt_id -eq $AttemptId)}catch{$record.parse_error='INVALID_CRASH_TOKEN_TRACE'}
 }else{
  try{
   $result=$stdout|ConvertFrom-Json;$record.result=$result
   $record.identity_evidence_valid=($result.actual_sid -eq $ExpectedSids[$Job.role] -and $result.native_token.sid -eq $ExpectedSids[$Job.role] -and -not $result.native_token.elevated -and $result.attempt_id -eq $AttemptId -and $result.worker_sha256 -eq $ExpectedWorkerHash -and $result.reviewed_sha -eq $FixedSha -and $result.probe_revision -eq 'r2' -and -not $result.real_final_test_executed)
   if($p.ExitCode -eq 0 -and -not $result.all_checks_passed){$record.expected_exit=$false}
   if($p.ExitCode -eq 42 -and $result.expected_rejection -ne 'TEST_ALREADY_CONSUMED_OR_CONTAMINATED'){$record.expected_exit=$false}
  }catch{$record.parse_error='INVALID_OR_INCOMPLETE_JSON_STDOUT';$record.expected_exit=$false}
 }
 $Results.Add($record)
 Write-Json (Join-Path $ExportPath 'process-results.json') @($Results.ToArray())
 Write-Host ($Job.label+': exit '+$p.ExitCode+'; native identity '+$record.identity_evidence_valid)
 return $record
}

function Require-RoleResult($Record) {
 if(-not $Record.expected_exit -or -not $Record.identity_evidence_valid){throw ('ROLE_CHECK_FAILED: '+$Record.label)}
}

function Test-ReadOnlyRuntimeAcl([string]$Folder,[hashtable]$Readers,[string]$Output) {
 [void](Assert-Root $Folder)
 $allowed=@{$ExpectedOwner=$true;'S-1-5-18'=$true;'S-1-5-32-544'=$true}
 foreach($sid in $Readers.Keys){$allowed[$sid]=$true}
 $writeMask=[Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Delete -bor [Security.AccessControl.FileSystemRights]::ChangePermissions -bor [Security.AccessControl.FileSystemRights]::TakeOwnership -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles
 $rows=[Collections.Generic.List[object]]::new();$count=0
 foreach($item in @((Get-Item -LiteralPath $Folder))+@(Get-ChildItem -LiteralPath $Folder -Recurse -Force)){
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'LINK_IN_DEPLOYED_RUNTIME'}
  $acl=Get-Acl -LiteralPath $item.FullName
  if(-not $acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $ExpectedOwner){throw ('RUNTIME_ACL_PROTECTION_OR_OWNER_MISMATCH: '+$item.FullName)}
  $seen=@{}
  foreach($ace in $acl.Access){
   $sid=$ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
   if($ace.AccessControlType -ne 'Allow' -or -not $allowed.ContainsKey($sid)){throw ('UNEXPECTED_RUNTIME_ACE: '+$item.FullName)}
   if($Readers.ContainsKey($sid) -and (([int]$ace.FileSystemRights -band [int]$writeMask) -ne 0)){throw ('ROLE_WRITABLE_RUNTIME: '+$item.FullName)}
   $seen[$sid]=$true
  }
  foreach($sid in $allowed.Keys){if(-not $seen.ContainsKey($sid)){throw ('MISSING_EXPECTED_RUNTIME_ACE: '+$item.FullName)}}
  $rows.Add(@{path=$item.FullName;owner=$ExpectedOwner;protected=$true;sddl=$acl.Sddl})
  $count++;if(($count%1000)-eq 0){Write-Host ('Runtime ACL nodes checked: '+$count)}
 }
 Write-Json $Output @($rows.ToArray())
 return @{nodes=$count;result='PASS';path=$Folder;scope='Every runtime file/directory ACL metadata; representative actual-token deny controls run separately'}
}

function Save-Observation([string]$Name) {
 $rows=[Collections.Generic.List[object]]::new()
 foreach($item in @((Get-Item -LiteralPath $TargetRoot))+@(Get-ChildItem -LiteralPath $TargetRoot -Recurse -Force)){
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'LINK_IN_VERIFICATION_TREE'}
  if($item.FullName -match '\\runtime_(eval|public)\\' -and -not $item.PSIsContainer -and $item.Name -notin @('python.exe','reviewed_code.json','python313._pth')){continue}
  $acl=Get-Acl -LiteralPath $item.FullName
  $rows.Add(@{path=$item.FullName;owner=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;protected=$acl.AreAccessRulesProtected;sddl=$acl.Sddl})
 }
 Write-Json (Join-Path $ExportPath ('acl-'+$Name+'.json')) @($rows.ToArray())
 $data=& "$env:SystemRoot\System32\icacls.exe" $TargetRoot /verify /t /c 2>&1
 $exit=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $ExportPath ('icacls-'+$Name+'.log')),($data|Out-String),$Utf8)
 if($exit -ne 0){throw 'ICACLS_VERIFY_FAILED'}
}
