"""Windows multi-principal ENGINEERING verification. Never calls purpose=FINAL_TEST."""
import base64,ctypes,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
from aqrp.factors.admission import bundle_hash
from aqrp.core.environment import runtime_manifest,verify_runtime
from aqrp.core.errors import ContractError
from aqrp.validation.evaluator import OperatorPolicy,TestEvaluator,identity,readonly_runtime
from aqrp.validation.approvals import propose
"""Reviewer helper candidate only; not installed in verification entry or AQRP package.
Require BOTH Python permission denial and native ERROR_ACCESS_DENIED. A generic
PermissionError alone must not make missing paths/sharing violations pass.
"""
import ctypes, errno, os
from pathlib import Path

def python_open_probe(path,write=False):
    try:
        if write:
            # OPEN_EXISTING equivalent: never create/truncate/write an absent target.
            fd=os.open(path,os.O_WRONLY|os.O_APPEND|getattr(os,'O_BINARY',0))
            os.close(fd)
        else:
            with Path(path).open('rb') as stream: stream.read(1)
        return dict(opened=True,error=None)
    except OSError as e:
        return dict(opened=False,error=dict(type=type(e).__name__,errno=e.errno,winerror=e.winerror,strerror=e.strerror))

def native_open_probe(path,write=False,share=7):
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
    k.CreateFileW.restype=ctypes.c_void_p
    k.CloseHandle.argtypes=[ctypes.c_void_p]; k.CloseHandle.restype=ctypes.c_int
    access=4 if write else 1 # FILE_APPEND_DATA / FILE_READ_DATA
    ctypes.set_last_error(0)
    h=k.CreateFileW(str(path),access,share,None,3,0x02000000,None) # OPEN_EXISTING
    error=ctypes.get_last_error()
    if h==ctypes.c_void_p(-1).value:
        return dict(opened=False,winerror=error,access=access,creation_disposition=3)
    if not k.CloseHandle(h): raise ctypes.WinError(ctypes.get_last_error())
    return dict(opened=True,winerror=0,access=access,creation_disposition=3)

def expected_permission_denied(py,native):
    e=py.get('error') or {}
    compatible=e.get('type')=='PermissionError' and (e.get('errno') in (errno.EACCES,errno.EPERM) or e.get('winerror')==5)
    return not py['opened'] and compatible and not native['opened'] and native['winerror']==5

"""Read only current Windows process token; no token change or elevated operation."""
import ctypes

def native_token():
    k=ctypes.WinDLL('kernel32',use_last_error=True); a=ctypes.WinDLL('advapi32',use_last_error=True)
    k.GetCurrentProcess.restype=ctypes.c_void_p
    k.CloseHandle.argtypes=[ctypes.c_void_p]; k.CloseHandle.restype=ctypes.c_int
    k.LocalFree.argtypes=[ctypes.c_void_p]; k.LocalFree.restype=ctypes.c_void_p
    a.OpenProcessToken.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p)];a.OpenProcessToken.restype=ctypes.c_int
    a.GetTokenInformation.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint32)];a.GetTokenInformation.restype=ctypes.c_int
    a.ConvertSidToStringSidW.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];a.ConvertSidToStringSidW.restype=ctypes.c_int
    token=ctypes.c_void_p()
    if not a.OpenProcessToken(k.GetCurrentProcess(),8,ctypes.byref(token)): raise ctypes.WinError(ctypes.get_last_error())
    try:
        size=ctypes.c_uint32();a.GetTokenInformation(token,1,None,0,ctypes.byref(size))
        if ctypes.get_last_error()!=122 or not size.value: raise ctypes.WinError(ctypes.get_last_error())
        data=ctypes.create_string_buffer(size.value)
        if not a.GetTokenInformation(token,1,data,len(data),ctypes.byref(size)): raise ctypes.WinError(ctypes.get_last_error())
        sid_pointer=ctypes.cast(data,ctypes.POINTER(ctypes.c_void_p))[0]; value=ctypes.c_void_p()
        if not a.ConvertSidToStringSidW(sid_pointer,ctypes.byref(value)): raise ctypes.WinError(ctypes.get_last_error())
        try: sid=ctypes.wstring_at(value)
        finally: k.LocalFree(value)
        elevated=ctypes.c_uint32();size=ctypes.c_uint32()
        if not a.GetTokenInformation(token,20,ctypes.byref(elevated),ctypes.sizeof(elevated),ctypes.byref(size)): raise ctypes.WinError(ctypes.get_last_error())
        return dict(sid=sid,elevated=bool(elevated.value),source='OpenProcessToken/GetTokenInformation; not role string or whoami output')
    finally:
        if not k.CloseHandle(token): raise ctypes.WinError(ctypes.get_last_error())

EXPECTED="3cec8a9da49a49a93010d7fa6a2012dded25185e2cdca49144cf4d719d56876e"
def raw_command(args):
 p=subprocess.run(args,capture_output=True)
 return dict(argv=args,exit_code=p.returncode,stdout=p.stdout.decode("utf-8","replace"),stderr=p.stderr.decode("utf-8","replace"),stdout_base64=base64.b64encode(p.stdout).decode(),stderr_base64=base64.b64encode(p.stderr).decode())
def emit(obj,code=0):
 print(json.dumps(obj,ensure_ascii=True,sort_keys=True));sys.exit(code)
if sys.argv[1:] == ["--self-test"]:
 m=runtime_manifest();verify_runtime(m);assert bundle_hash()==EXPECTED
 emit(dict(bundle_hash=bundle_hash(),runtime=m,isolated=sys.flags.isolated,no_user_site=sys.flags.no_user_site,dont_write_bytecode=sys.dont_write_bytecode,module_file=__import__("aqrp").__file__,scope="PORTABLE RUNTIME SELF-TEST ONLY"))
if len(sys.argv)!=4:emit({"error":"FIXED_ARGUMENTS_REQUIRED"},44)
role,mode,config_path=sys.argv[1:]
if role not in ("research","evaluator","auditor") or mode not in ("inspect","post-inspect","race","crash","recover","after","abort-before","alias"):
 emit({"error":"CLOSED_ENTRY_ARGUMENTS"},44)
cfg=json.loads(Path(config_path).read_bytes())
root=Path(cfg["root"]);sealed=root/"sealed";actual=identity();native_identity=native_token()
import uuid
attempt=str(uuid.UUID(cfg["attempt_id"]))
if cfg["scope"]!="ENGINEERING_DEMO_ONLY" or cfg["reviewed_sha"]!="9ac5db069287a6e4a095e25ae8c3cc8fa229cded" or cfg["nonce"]!="95d4afc7-a9e7-487b-a918-434070c12425":
 emit({"error":"CLOSED_ENGINEERING_CONFIG_REQUIRED"},44)
if str(root)!="C:\\AQRP-Sealed\\verify-9ac5db0":emit({"error":"WRONG_ROOT"},44)
ns="engineering-r2-"+attempt
private_control=sealed/"control"/ns;private_work=sealed/"work"/ns
if cfg["engineering_paths"]!={"control":"sealed/control/"+ns,"work":"sealed/work/"+ns}:emit({"error":"WRONG_ENGINEERING_NAMESPACE"},44)
if native_identity["sid"]!=cfg["principals"][role] or native_identity["elevated"]:
 emit(dict(error="WRONG_NATIVE_TOKEN",native_token=native_identity,role=role),43)
if actual!=cfg["principals"][role]:
 emit(dict(error="WRONG_ROLE_IDENTITY",role=role,actual_sid=actual),43)
assert bundle_hash()==EXPECTED
verify_runtime(runtime_manifest())
expected_runtime=root/("runtime_eval" if role=="evaluator" else "runtime_public")/"python.exe"
assert Path(sys.executable).resolve()==expected_runtime.resolve()
checks=[]
def check(name,condition,**detail):
 checks.append(dict(name=name,pass_=bool(condition),**detail))
def read_allowed(path,name,allowed):
 py=python_open_probe(path);native=native_open_probe(path)
 passed=(py["opened"] and native["opened"]) if allowed else expected_permission_denied(py,native)
 check(name,passed,expected_read=allowed,python=py,native=native,path=str(path))

def write_denied(path,name):
 py=python_open_probe(path,True);native=native_open_probe(path,True)
 check(name,expected_permission_denied(py,native),python=py,native=native,path=str(path))

def access_right_denied(path,right,name):
 k=ctypes.WinDLL("kernel32",use_last_error=True)
 k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
 k.CreateFileW.restype=ctypes.c_void_p
 k.CloseHandle.argtypes=[ctypes.c_void_p];k.CloseHandle.restype=ctypes.c_int
 h=k.CreateFileW(str(path),right,7,None,3,0x02000000,None)
 err=ctypes.get_last_error()
 if h!=ctypes.c_void_p(-1).value:k.CloseHandle(h);denied=False
 else:denied=err==5
 check(name,denied,requested_access=right,winerror=err,path=str(path))
def policy():
 p=cfg["principals"]
 return OperatorPolicy(sealed,sealed/"operator-key",evaluator=p["evaluator"],research=p["research"],auditor=p["auditor"],trusted_owner=p["trusted_owner"])
def host_check(name):
 try:
  key=policy().verify_host()
  check(name,len(key)==32,returned_key_logged=False)
 except Exception as e:check(name,False,error_code=getattr(e,"code",type(e).__name__),error_message=str(e))
def engineering_factor_run():
 from datetime import date
 from decimal import Decimal
 from math import isclose
 from aqrp.core.contracts import QuerySpec
 from aqrp.data.synthetic import load_synthetic,PROVENANCE
 from aqrp.data.snapshot import publish_snapshot
 from aqrp.factors import FactorEngine,FactorRegistry,builtin_spec,write_run
 output=private_work/"engineering-factor-run"
 tables=load_synthetic(sessions=[(date(2024,1,d),"12:00:00") for d in (2,3,4)])
 for row in tables["bars_daily"]:
  i=row["session_date"].day-2;price=Decimal((100,110,121)[i]);volume=Decimal((100,150,200)[i])
  row.update({k:price for k in ("open","high","low","close")})
  row.update(volume=volume,source_volume=str(volume),amount=price*volume,source_amount=str(price*volume))
 snapshot=publish_snapshot(tables,PROVENANCE,output/"snapshot")
 query=QuerySpec(("SYN_A:001",),"SYN_A","SYN_A_CAL",(date(2024,1,2),date(2024,1,4)),("close","volume"),"split_adjusted")
 registry=FactorRegistry();values={}
 # Fixed hand answers from prices100,110,121 and volumes100,150,200:
 # momentum=.21, reversal=-.21, volume=200/125-1=.6,
 # price_volume=(121/110-1)*(200/125-1)=.06. No implementation-generated expected.
 for name,expected in (("momentum",.21),("reversal",-.21),("volume",.6),("price_volume",.06)):
  spec=builtin_spec(name)
  registry.register(spec.implementation_version,spec,actor="GPT Work Windows engineering probe",reason="fixed reviewed builtin only; not financial approval",evidence=spec.review_ref)
  batch=FactorEngine(registry).run(spec.ref,query,"2024-01-04T12:05:00Z",snapshot,parameters={"lookback":2})
  value=batch.rows[0].factor_value
  check("real_installed_factor:"+name,isclose(value,expected,abs_tol=1e-12,rel_tol=1e-10),actual=value,expected=expected)
  write_run(batch,output/"factor-runs",registry)
  values[name]=dict(value=value,logical_hash=batch.logical_hash)
 result["actual_engineering_factor_execution"]=dict(snapshot_manifest_hash=snapshot.manifest_hash,values=values,financial_approval=False,formal_test=False)
def independent_chain(path):
 rows=[json.loads(x) for x in path.read_bytes().splitlines()];previous="0"*64
 for i,r in enumerate(rows):
  value={k:v for k,v in r.items() if k!="hash"}
  digest=hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
  assert r["seq"]==i and r["previous"]==previous and r["hash"]==digest
  previous=r["hash"]
 return rows
result=dict(role=role,mode=mode,actual_sid=actual,native_token=native_identity,attempt_id=attempt,probe_revision="r2",worker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reviewed_sha=cfg["reviewed_sha"],bundle_hash=EXPECTED,purpose="ENGINEERING_DEMO",real_final_test_executed=False,started_utc=datetime.now(timezone.utc).isoformat(),checks=checks)
if mode=="inspect":
 result["token"]={name:raw_command(["whoami",arg,"/fo","csv","/nh"]) for name,arg in (("user","/user"),("groups","/groups"),("privileges","/priv"))}
 check("token_commands_succeeded",all(v["exit_code"]==0 for v in result["token"].values()))
 groups=result["token"]["groups"]["stdout"]
 check("non_admin_no_backup_operator",not any(s in groups for s in ("S-1-5-32-544","S-1-5-32-551")))
 privileges=result["token"]["privileges"]["stdout"]
 check("no_debug_backup_restore_tcb_impersonation_privilege",not any(x in privileges for x in ("SeDebugPrivilege","SeBackupPrivilege","SeRestorePrivilege","SeTcbPrivilege","SeImpersonatePrivilege")))
 read_allowed(root/"public/engineering-canary.json","public_projection_read",True)
 private_files=["inputs/snapshot-canary.json","inputs/labels-canary.json","inputs/seed-canary.json","inputs/backup-canary.json","inbox/request-canary.json","work/temp-canary.json","work/cache-canary.json","logs/log-canary.json","results/result-canary.json","control/ledger-canary.json"]
 for rel in private_files:
  path=sealed/rel
  read_allowed(path,"private_read:"+rel,role!="research")
  if role!="evaluator" or rel.startswith(("inputs/","inbox/")):
   write_denied(path,"private_write:"+rel)
  else:
   py=python_open_probe(path,True);native=native_open_probe(path,True)
   check("evaluator_work_write:"+rel,py["opened"] and native["opened"],python=py,native=native)
 read_allowed(sealed/"operator-key","operator_key_read",role=="evaluator")
 write_denied(sealed/"operator-key","operator_key_write")
 for path in (Path(__file__).resolve(),Path(config_path),root/"entry/worker.py",root/"entry/config.json",root/"entry/ADMIN_ENTRYPOINT.ps1",expected_runtime,expected_runtime.parent/"Lib/site-packages/aqrp/factors/reviewed_code.json"):
  write_denied(path,"immutable_runtime_or_entry_write:"+str(path.relative_to(root)))
  access_right_denied(path,0x40000,"cannot_change_dacl:"+str(path.relative_to(root)))
  access_right_denied(path,0x80000,"cannot_take_owner:"+str(path.relative_to(root)))
 if role=="research":
  for path in (sealed,sealed/"inputs",sealed/"control",sealed/"results"):
   try:list(path.iterdir());py={"opened":True,"error":None}
   except OSError as e:py={"opened":False,"error":{"type":type(e).__name__,"errno":e.errno,"winerror":e.winerror,"strerror":e.strerror}}
   native=native_open_probe(path)
   check("private_list:"+str(path.relative_to(root)),expected_permission_denied(py,native),python=py,native=native)
  read_allowed(root/"runtime_eval/python.exe","private_eval_runtime_read",False)
  p=subprocess.run([sys.executable,"-B","-I",str(Path(__file__).resolve()),"evaluator","inspect",config_path],capture_output=True)
  check("research_cannot_claim_evaluator_role",p.returncode==43,exit_code=p.returncode)
 if role=="auditor":
  read_allowed(root/"runtime_eval/python.exe","auditor_runtime_read",True)
 if role=="evaluator":
  host_check("real_operator_policy_verify_host_before")
  for rel in ("python.exe","Lib/site-packages/aqrp/factors/reviewed_code.json"):
   try:
    readonly_runtime(root/"runtime_eval"/rel,cfg["principals"]["trusted_owner"],set(cfg["principals"].values())|{"S-1-5-18","S-1-5-32-544"},cfg["principals"]["research"])
    ok=True;error=None
   except Exception as e:ok=False;error=str(e)
   check("readonly_runtime:"+rel,ok,error=error)
  engineering_factor_run()
  called=[]
  try:TestEvaluator(sealed/"never-formal-created").process({"holdout_lineage_id":"PUBLIC_ENGINEERING_ONLY"},lambda:called.append(True),purpose="FINAL_TEST")
  except ContractError as e:code=e.code
  else:code=None
  check("formal_refused_before_callback",code=="UNVERIFIED_ISOLATION" and not called and not (sealed/"never-formal-created").exists(),error_code=code)
  proposal=propose({"fixture":"PUBLIC_ENGINEERING_ONLY"},{},{"mean":.9,"n":10000,"positive_fraction":1},{"complete":True,"adjusted":[.000001]},{"purpose":"ENGINEERING_DEMO","independence_verified":False},{})
  check("no_financial_approval_without_standards_or_test",not proposal["eligible"] and "UNAPPROVED_STANDARDS" in proposal["failures"],failures=proposal["failures"])
elif mode=="post-inspect":
 for path in [private_control/"demo-race/access.jsonl",private_control/"demo-crash/access.jsonl",private_work/"race.go"]:
  read_allowed(path,"dynamic_read:"+str(path.relative_to(root)),role!="research")
  if role!="evaluator":write_denied(path,"dynamic_write:"+str(path.relative_to(root)))
elif role!="evaluator":emit({"error":"EVALUATOR_MODE_REQUIRED"},43)
elif mode=="abort-before":
 check("abort_before_reservation_no_chain",not (private_control/"demo-abort/access.jsonl").exists())
elif mode in ("race","crash"):
 case=private_control/("demo-race" if mode=="race" else "demo-crash")
 if mode=="race":
  ready=private_work/("race-ready-"+str(os.getpid())+".json");ready.write_text("PUBLIC ENGINEERING READY")
  deadline=time.monotonic()+40
  while not (private_work/"race.go").exists():
   if time.monotonic()>deadline:emit({"error":"BARRIER_TIMEOUT"},45)
   time.sleep(.02)
 def callback():
  if mode=="crash":
   print(json.dumps({"event":"ENGINEERING_CRASH_BEFORE_RESULT","native_token":native_identity,"attempt_id":attempt,"purpose":"ENGINEERING_DEMO"}),file=sys.stderr,flush=True)
   os._exit(23)
  read_allowed(sealed/"inputs/snapshot-canary.json","evaluator_callback_private_read",True)
  return {"scope":"PUBLIC_ENGINEERING_ONLY","constant":17}
 try:
  answer=TestEvaluator(case).process({"holdout_lineage_id":case.name},callback,purpose="ENGINEERING_DEMO")
  result["evaluation"]=answer;check("engineering_demo_executed",True)
 except ContractError as e:
  if e.code!="TEST_ALREADY_CONSUMED_OR_CONTAMINATED":raise
  result["expected_rejection"]=e.code
  result["checks"]=checks;emit(result,42)
elif mode=="recover":
 case=private_control/"demo-crash";ev=TestEvaluator(case)
 recovered=ev.recover();again=ev.recover()
 check("recovery_marks_consumed_once",recovered==1 and again==0,recovered=recovered,second_recover=again)
 try:ev.process({"holdout_lineage_id":case.name},lambda:{"constant":18},purpose="ENGINEERING_DEMO")
 except ContractError as e:code=e.code
 else:code=None
 check("crash_does_not_return_budget",code=="TEST_ALREADY_CONSUMED_OR_CONTAMINATED",error_code=code)
 rows=independent_chain(case/"access.jsonl")
 check("crash_chain", [r["kind"] for r in rows]==["RESERVED","FAILED_CONSUMED","REJECTED_REPEAT"],event_kinds=[r["kind"] for r in rows])
elif mode=="alias":
 case=private_control/"demo-race"
 for extra in ({"family":"renamed"},{"run_id":"renamed"},{"protocol_hash":"different"},{"cache":"hit"}):
  try:TestEvaluator(case).process({"holdout_lineage_id":case.name,**extra},lambda:{"constant":19},purpose="ENGINEERING_DEMO")
  except ContractError as e:code=e.code
  else:code=None
  check("same_identity_alias_rejected:"+str(extra),code=="TEST_ALREADY_CONSUMED_OR_CONTAMINATED",error_code=code)
elif mode=="after":
 # Do not repair ACLs before this check: dynamically-created-file behavior is evidence.
 host_check("operator_policy_verify_host_after_dynamic_engineering_files")
 rows=independent_chain(private_control/"demo-race/access.jsonl");kinds=[r["kind"] for r in rows]
 check("single_race_reservation",kinds.count("RESERVED")==1 and kinds.count("SUCCEEDED")==1,event_kinds=kinds)
 result["unverified_cases"]=["all real power-loss and result-write crash boundaries","formal private holdout and cross-path final-policy/cache identity controls","network containment beyond no inherited credentials","Ubuntu multi-principal profile"]
result["finished_utc"]=datetime.now(timezone.utc).isoformat()
result["all_checks_passed"]=all(x["pass_"] for x in checks)
emit(result,0 if result["all_checks_passed"] else 2)

