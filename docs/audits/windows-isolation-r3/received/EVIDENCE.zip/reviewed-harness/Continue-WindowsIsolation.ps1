[CmdletBinding()]
param([switch]$Check)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$env:PSModulePath=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\Modules'
$ExpectedOwner='S-1-5-21-2664406737-4182919061-3647612378-1001'
$FixedSha='9ac5db069287a6e4a095e25ae8c3cc8fa229cded'
$ExpectedNonce='95d4afc7-a9e7-487b-a918-434070c12425'
$TargetRoot='C:\AQRP-Sealed\verify-9ac5db0'
$ParentRoot='C:\AQRP-Sealed'
$PackageRoot=Join-Path (Split-Path $PSScriptRoot -Parent) 'windows-isolation-9ac5db0'
$RecoveryRoot=$PSScriptRoot
$OldRecovery=Join-Path (Split-Path $PSScriptRoot -Parent) 'windows-isolation-9ac5db0-recovery1'
$CurrentIdentity=[Security.Principal.WindowsIdentity]::GetCurrent()
$CurrentPrincipal=[Security.Principal.WindowsPrincipal]::new($CurrentIdentity)
$Utf8=[Text.UTF8Encoding]::new($false)
$LocalNames=@{research='aqrp_research';evaluator='aqrp_evaluator';auditor='aqrp_auditor'}
$ExpectedSids=@{research='S-1-5-21-2664406737-4182919061-3647612378-1007';evaluator='S-1-5-21-2664406737-4182919061-3647612378-1008';auditor='S-1-5-21-2664406737-4182919061-3647612378-1009'}
$ManifestPath=Join-Path $PSScriptRoot 'PREPARATION_MANIFEST.json'
$manifest=Get-Content -LiteralPath $ManifestPath -Raw|ConvertFrom-Json
if($manifest.reviewed_sha -ne $FixedSha -or $manifest.root -ne $TargetRoot -or $manifest.nonce -ne $ExpectedNonce){throw 'REVISION_MANIFEST_BINDING_MISMATCH'}
foreach($e in $manifest.deploy_files){
 if($e.path -notin @('worker-r2.py','Continuation-Helpers.ps1','Continue-WindowsIsolation.ps1')){throw 'UNEXPECTED_DEPLOY_FILE'}
 $p=Join-Path $PSScriptRoot $e.path
 if((Get-Item -LiteralPath $p).Length -ne $e.bytes -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne $e.sha256){throw 'REVISION_FILE_HASH_MISMATCH'}
}
if(@($manifest.deploy_files).Count -ne 3 -or @($manifest.deploy_files.path|Select-Object -Unique).Count -ne 3){throw 'REVISION_FILE_SET_MISMATCH'}
. (Join-Path $PSScriptRoot 'Continuation-Helpers.ps1')
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -ne 'Desktop'){throw 'USE_64_BIT_WINDOWS_POWERSHELL_5_1'}
if($CurrentIdentity.User.Value -ne $ExpectedOwner){throw 'WRONG_TRUSTED_OWNER_SID'}
foreach($file in @($PSCommandPath,(Join-Path $PSScriptRoot 'Continuation-Helpers.ps1'))){
 $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw 'POWERSHELL_PARSE_ERROR'}
}
if(-not $Check){Require-Admin}
[void](Assert-Root $TargetRoot)
if((Get-Acl -LiteralPath $TargetRoot).GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $ExpectedOwner){throw 'ROOT_OWNER_MISMATCH'}
$accounts=@()
foreach($role in @('research','evaluator','auditor')){
 $u=Get-LocalUser -Name $LocalNames[$role]
 if($u.SID.Value -ne $ExpectedSids[$role] -or $u.Description -ne ('AQRP verify '+$ExpectedNonce) -or $u.Enabled){throw 'ACCOUNT_IDENTITY_OR_DISABLED_STATE_MISMATCH'}
 $accounts+=@{role=$role;name=$u.Name;sid=$u.SID.Value}
}
$originalState=Get-Content -LiteralPath (Join-Path $TargetRoot 'DEPLOYMENT_STATE.json') -Raw|ConvertFrom-Json
if($originalState.root -ne $TargetRoot -or $originalState.fixed_sha -ne $FixedSha -or $originalState.nonce -ne $ExpectedNonce -or $originalState.owner_sid -ne $ExpectedOwner -or $originalState.status -ne 'FAILED_CLOSED' -or $originalState.attempt_id -ne '7ae4dc34-bcb0-4776-8c5e-146cb2c55c8d'){throw 'ORIGINAL_FAILED_STATE_MISMATCH'}
$baseConfig=Get-Content -LiteralPath (Join-Path $TargetRoot 'entry\config.json') -Raw|ConvertFrom-Json
if($baseConfig.root -ne $TargetRoot -or $baseConfig.reviewed_sha -ne $FixedSha -or $baseConfig.scope -ne 'ENGINEERING_DEMO_ONLY' -or $baseConfig.nonce -ne $ExpectedNonce){throw 'ORIGINAL_ENGINEERING_CONFIG_MISMATCH'}
foreach($entry in $accounts){if($baseConfig.principals.($entry.role) -ne $entry.sid){throw 'ORIGINAL_PRINCIPALS_MISMATCH'}}
if($baseConfig.principals.trusted_owner -ne $ExpectedOwner){throw 'ORIGINAL_TRUSTED_OWNER_MISMATCH'}
if(Test-Path -LiteralPath (Join-Path $TargetRoot 'sealed\authorization.json')){throw 'FORMAL_AUTHORIZATION_PRESENT_REFUSE_ENGINEERING_CONTINUATION'}
if((Get-FileHash -LiteralPath (Join-Path $TargetRoot 'entry\worker.py') -Algorithm SHA256).Hash.ToLower() -ne $manifest.original_worker_sha256){throw 'ORIGINAL_INSTALLED_WORKER_CHANGED'}
if((Get-FileHash -LiteralPath (Join-Path $PackageRoot 'PAYLOAD_MANIFEST.json') -Algorithm SHA256).Hash.ToLower() -ne $manifest.original_payload_manifest_sha256){throw 'ORIGINAL_PAYLOAD_MANIFEST_CHANGED'}
$AttemptId=[guid]::NewGuid().ToString()
$ExportPath=Join-Path $PSScriptRoot ($(if($Check){'preflight'}else{'results'})+'\'+$AttemptId)
[void][IO.Directory]::CreateDirectory($ExportPath)
$transcriptStarted=$false
try{Start-Transcript -LiteralPath (Join-Path $ExportPath 'transcript.txt') -NoClobber|Out-Null;$transcriptStarted=$true}catch{}
$Passwords=@{};$Processes=[Collections.Generic.List[Diagnostics.Process]]::new();$Results=[Collections.Generic.List[object]]::new()
$ExpectedWorkerHash=@($manifest.deploy_files|Where-Object {$_.path -eq 'worker-r2.py'})[0].sha256
$WorkerPath=Join-Path $TargetRoot 'entry\worker-r2.py'
$ConfigPath=Join-Path $TargetRoot ('entry\config-r2-'+$AttemptId+'.json')
$PrivateControl=Join-Path $TargetRoot ('sealed\control\engineering-r2-'+$AttemptId)
$PrivateWork=Join-Path $TargetRoot ('sealed\work\engineering-r2-'+$AttemptId)
$PublicRead=@{};foreach($sid in $ExpectedSids.Values){$PublicRead[$sid]='ReadAndExecute'}
$PrivateRead=@{$ExpectedSids.evaluator='ReadAndExecute';$ExpectedSids.auditor='ReadAndExecute'}
$PrivateWrite=@{$ExpectedSids.evaluator='Modify';$ExpectedSids.auditor='ReadAndExecute'}
$State=@{attempt_id=$AttemptId;utc=[DateTime]::UtcNow.ToString('o');root=$TargetRoot;fixed_sha=$FixedSha;nonce=$ExpectedNonce;accounts=$accounts;formal_test_authorized=$false;financial_approval='NONE';probe_revision='r2';worker_sha256=$ExpectedWorkerHash;driver_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLower();helpers_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'Continuation-Helpers.ps1') -Algorithm SHA256).Hash.ToLower();status='PREFLIGHT_STARTED';original_failed_attempt=$originalState.attempt_id;original_state_not_overwritten=$true}
try{
 Copy-Item -LiteralPath (Join-Path $TargetRoot 'DEPLOYMENT_STATE.json') -Destination (Join-Path $ExportPath 'original-failed-state.json')
 Write-Host 'Verifying original payload and both installed runtimes; no source or old entry changes.'
 $payload=Check-Payload
 $runtimeRows=@($payload.files|Where-Object {$_.path.StartsWith('runtime/')})
 foreach($dest in @('runtime_public','runtime_eval')){
  $folder=Join-Path $TargetRoot $dest
  $actualFiles=@(Get-ChildItem -LiteralPath $folder -Recurse -File -Force)
  if($actualFiles.Count -ne $runtimeRows.Count){throw 'DEPLOYED_RUNTIME_FILE_SET_MISMATCH'}
  foreach($row in $runtimeRows){
   $p=Join-Path $folder $row.path.Substring(8)
   if((Get-Item -LiteralPath $p).Length -ne $row.bytes -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne $row.sha256){throw 'DEPLOYED_RUNTIME_BYTES_CHANGED'}
  }
 }
 $State.runtime_file_count_each=$runtimeRows.Count
 $oldAcl=Join-Path $OldRecovery 'results\7ae4dc34-bcb0-4776-8c5e-146cb2c55c8d\admin-evidence\acl-resume-before-7ae4dc34-bcb0-4776-8c5e-146cb2c55c8d.json'
 $observed=Get-Content -LiteralPath $oldAcl -Raw|ConvertFrom-Json
 foreach($row in $observed){[void](Assert-Root $row.path);if((Get-Acl -LiteralPath $row.path).Sddl -ne $row.sddl){throw ('PREVIOUS_ACL_DRIFT: '+$row.path)}}
 $State.prior_acl_rows_unchanged=@($observed).Count
 $State.runtime_public_acl=Test-ReadOnlyRuntimeAcl (Join-Path $TargetRoot 'runtime_public') $PublicRead (Join-Path $ExportPath 'runtime-public-acls.json')
 $State.runtime_eval_acl=Test-ReadOnlyRuntimeAcl (Join-Path $TargetRoot 'runtime_eval') $PrivateRead (Join-Path $ExportPath 'runtime-eval-acls.json')
 if($Check){
  $State.status='PREPARATION_READONLY_CHECK_PASS';$State.no_account_or_target_mutation=$true
 }else{
  # Accounts are still disabled during these exact, bounded validation-entry writes.
  if(Test-Path -LiteralPath $WorkerPath){
   if((Get-FileHash -LiteralPath $WorkerPath -Algorithm SHA256).Hash.ToLower() -ne $ExpectedWorkerHash){throw 'EXISTING_R2_WORKER_CHANGED'}
  }else{Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'worker-r2.py') -Destination $WorkerPath}
  Set-ExactAcl $WorkerPath $PublicRead
  foreach($dir in @($PrivateControl,$PrivateWork)){
   [void](Assert-Root $dir);if(Test-Path -LiteralPath $dir){throw 'ATTEMPT_DIRECTORY_EXISTS'}
   [void][IO.Directory]::CreateDirectory($dir);Set-ExactAcl $dir $PrivateWrite
  }
  $cfg=@{scope='ENGINEERING_DEMO_ONLY';root=$TargetRoot;nonce=$ExpectedNonce;reviewed_sha=$FixedSha;attempt_id=$AttemptId;principals=@{trusted_owner=$ExpectedOwner;research=$ExpectedSids.research;evaluator=$ExpectedSids.evaluator;auditor=$ExpectedSids.auditor};engineering_paths=@{control=('sealed/control/engineering-r2-'+$AttemptId);work=('sealed/work/engineering-r2-'+$AttemptId)}}
  if(Test-Path -LiteralPath $ConfigPath){throw 'CONFIG_ALREADY_EXISTS'}
  Write-Json $ConfigPath $cfg;Set-ExactAcl $ConfigPath $PublicRead
  $State.config_sha256=(Get-FileHash -LiteralPath $ConfigPath -Algorithm SHA256).Hash.ToLower()
  $State.config_path=$ConfigPath;$State.control=$PrivateControl;$State.work=$PrivateWork
  Save-Observation 'before-principals'
  $State.status='READY_FOR_REAL_PRINCIPAL_PROBES';Write-Json (Join-Path $ExportPath 'state-before.json') $State
  foreach($entry in $accounts){
   $Passwords[$entry.role]=New-Password
   Set-LocalUser -SID ([Security.Principal.SecurityIdentifier]::new($entry.sid)) -Password $Passwords[$entry.role]
   Enable-LocalUser -SID ([Security.Principal.SecurityIdentifier]::new($entry.sid))
  }
  foreach($role in @('research','auditor','evaluator')){Require-RoleResult (Complete-Role (Start-Role $role 'inspect' ($role+'-inspect')))}
  Require-RoleResult (Complete-Role (Start-Role 'evaluator' 'abort-before' 'evaluator-abort-before'))
  $raceA=Start-Role 'evaluator' 'race' 'evaluator-race-a';$raceB=Start-Role 'evaluator' 'race' 'evaluator-race-b'
  $deadline=[DateTime]::UtcNow.AddSeconds(45)
  do{$ready=@(Get-ChildItem -LiteralPath $PrivateWork -Filter 'race-ready-*.json');if($ready.Count -ge 2){break};Start-Sleep -Milliseconds 100}while([DateTime]::UtcNow -lt $deadline)
  if($ready.Count -ne 2){throw 'RACE_BARRIER_FAILED'}
  [IO.File]::WriteAllText((Join-Path $PrivateWork 'race.go'),'PUBLIC_ENGINEERING_GO',$Utf8)
  $a=Complete-Role $raceA @(0,42);$b=Complete-Role $raceB @(0,42)
  Require-RoleResult $a;Require-RoleResult $b
  if(((@($a.exit_code,$b.exit_code)|Sort-Object) -join ',') -ne '0,42'){throw 'RACE_REQUIRES_ONE_SUCCESS_AND_ONE_REJECTION'}
  Require-RoleResult (Complete-Role (Start-Role 'evaluator' 'crash' 'evaluator-crash') @(23))
  Require-RoleResult (Complete-Role (Start-Role 'evaluator' 'recover' 'evaluator-recover'))
  Require-RoleResult (Complete-Role (Start-Role 'evaluator' 'alias' 'evaluator-alias'))
  foreach($role in @('research','auditor','evaluator')){Require-RoleResult (Complete-Role (Start-Role $role 'post-inspect' ($role+'-post-inspect')))}
  # Never repair dynamic ACLs to force this policy check to pass.
  $after=Complete-Role (Start-Role 'evaluator' 'after' 'evaluator-after') @(0,2)
  if(-not $after.identity_evidence_valid){throw 'AFTER_IDENTITY_NOT_VERIFIED'}
  Save-Observation 'after-dynamic-files'
  $State.status=if(@($Results.ToArray()|Where-Object {$_.exit_code -eq 2 -or -not $_.expected_exit -or -not $_.identity_evidence_valid}).Count){'ENGINEERING_CHECKS_HAVE_FAILURES'}else{'ENGINEERING_CHECKS_COMPLETED_REVIEW_REQUIRED'}
 }
}catch{
 $State.status='FAILED_CLOSED';$State.error_message=$_.Exception.Message;$State.error_type=$_.Exception.GetType().FullName
 Write-Json (Join-Path $ExportPath 'failure.json') @{utc=[DateTime]::UtcNow.ToString('o');message=$State.error_message;type=$State.error_type;stack=$_.ScriptStackTrace}
 Write-Warning ('Stopped safely: '+$State.error_message)
}finally{
 foreach($p in $Processes){try{if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}catch{}}
 if(-not $Check){foreach($entry in $accounts){try{$u=Get-LocalUser -Name $entry.name;if($u.SID.Value -eq $entry.sid){Disable-LocalUser -SID $u.SID}}catch{Write-Warning ('Could not disable '+$entry.name)}}}
 foreach($password in $Passwords.Values){$password.Dispose()}
 $State.completed_utc=[DateTime]::UtcNow.ToString('o')
 $State.accounts_disabled=@(foreach($entry in $accounts){$u=Get-LocalUser -Name $entry.name;@{name=$entry.name;sid=$u.SID.Value;enabled=$u.Enabled}})
 Write-Json (Join-Path $ExportPath 'final-state.json') $State
 if($transcriptStarted){try{Stop-Transcript|Out-Null}catch{}}
}
Write-Host ('Status: '+$State.status);Write-Host ('Evidence: '+$ExportPath)
Write-Host 'Engineering only. No formal Test, financial approval, merge/tag, business implementation or deployment service.'
if(@($State.accounts_disabled|Where-Object {$_.enabled}).Count){Write-Warning 'ACCOUNT_STILL_ENABLED_REVIEW_REQUIRED';exit 3}
if($State.status -in @('FAILED_CLOSED','ENGINEERING_CHECKS_HAVE_FAILURES')){exit 2}
exit 0
