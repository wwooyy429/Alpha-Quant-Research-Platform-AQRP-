import pathlib,json,hashlib,zipfile,datetime
O=pathlib.Path(__file__).parent;excluded={'EVIDENCE_MANIFEST.json','EVIDENCE.zip','RECEIPT.json','seal.stdout.log','seal.stderr.log'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[{'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in excluded]
assert (O/'verify.stderr.log').stat().st_size==0 and (O/'git-verify.stderr.log').stat().st_size==0
assert json.loads((O/'FIXED_GIT_SOURCE_VERIFICATION.json').read_text())['all_bytes_identical']
manifest={'schema':'aqrp-independent-windows-r2-evidence/1','fixed_sha':'9ac5db069287a6e4a095e25ae8c3cc8fa229cded','attempt_id':'e6968f1c-3552-4a98-af61-98a5194dafea','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'conclusion':'NOT VERIFIED / BLOCKED for complete Windows isolation; partial engineering checks passed','scope_limit':'37 complete raw admin exports and 24 reachable engineering files; 9 inaccessible generated snapshot files excluded explicitly in OMISSIONS.json','files':files}
save(O/'EVIDENCE_MANIFEST.json',manifest)
with zipfile.ZipFile(O/'EVIDENCE.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(O/f['path'],f['path'])
 z.write(O/'EVIDENCE_MANIFEST.json','EVIDENCE_MANIFEST.json')
with zipfile.ZipFile(O/'EVIDENCE.zip') as z:
 assert z.testzip() is None;assert len(z.namelist())==len(files)+1
 for f in files:
  data=z.read(f['path']);assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256']
 assert z.read('EVIDENCE_MANIFEST.json')==(O/'EVIDENCE_MANIFEST.json').read_bytes()
 listing=[{'path':i.filename,'bytes':i.file_size,'crc32':format(i.CRC,'08x')} for i in z.infolist()]
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'zip':'EVIDENCE.zip','bytes':(O/'EVIDENCE.zip').stat().st_size,'sha256':sha(O/'EVIDENCE.zip'),'manifest_sha256':sha(O/'EVIDENCE_MANIFEST.json'),'manifest_files':len(files),'zip_members':len(listing),'all_member_hashes_and_crc_verified':True,'listing':listing,'not_digital_signature':True,'omitted_snapshot_files':9}
save(O/'RECEIPT.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k!='listing'}))
