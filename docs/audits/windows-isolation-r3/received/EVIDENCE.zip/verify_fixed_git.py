import pathlib,subprocess,hashlib,json,datetime,platform
O=pathlib.Path(r'C:/Users/11638/AppData/Local/AQRP/reviews/windows-isolation-9ac5db0-r2-e6968f1c-review');repo=pathlib.Path(r'C:/Users/11638/AppData/Local/AQRP/reviews/p4-plan-265af16');pkg=pathlib.Path(r'C:/AQRP-Sealed/verify-9ac5db0/runtime_eval/Lib/site-packages/aqrp');fixed='9ac5db069287a6e4a095e25ae8c3cc8fa229cded';commands=[]
def run(args):
 p=subprocess.run(args,capture_output=True);commands.append({'argv':args,'exit_code':p.returncode});p.check_returncode();return p.stdout
resolved=run(['git','-C',str(repo),'rev-parse',fixed+'^{commit}']).decode().strip();assert resolved==fixed
files=[]
for p in sorted(pkg.rglob('*.py')):
 rel='src/aqrp/'+p.relative_to(pkg).as_posix();data=run(['git','-C',str(repo),'show',fixed+':'+rel]);assert data==p.read_bytes(),rel;files.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest()})
doc=run(['git','-C',str(repo),'show',fixed+':docs/audits/phase-3/TEST_ISOLATION_PROFILE.md']);(O/'fixed-source/TEST_ISOLATION_PROFILE.md').write_bytes(doc)
who=run(['whoami','/user','/fo','csv','/nh']).decode('oem');version=run(['git','--version']).decode().strip()
(O/'FIXED_GIT_SOURCE_VERIFICATION.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixed_sha':resolved,'compared_modules':len(files),'all_bytes_identical':True,'files':files,'read_only_git_commands':commands,'git_version':version,'current_reviewer_user':who,'review_platform':platform.platform(),'no_checkout_or_repo_writes':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Fixed Git object: 45 deployed Python source modules byte-identical; profile retained; no repository mutations.')
