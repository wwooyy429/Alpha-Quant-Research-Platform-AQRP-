"""Seal immutable audit evidence after all reviewer execution logs are closed."""
import hashlib,json,subprocess,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
scope=json.loads((out/"scope-verification.json").read_bytes());root=Path(scope["environment"]["root"])
dev=Path("C:/Users/11638/AppData/Local/AQRP/checkouts/phase1-57461d5d-5de2-4c78-9b4e-5fad2b5ccb29")
commands=[]
def git(r,*args):
    p=subprocess.run(["git","-C",str(r),*args],capture_output=True,text=True)
    commands.append(dict(argv=p.args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode:raise RuntimeError(commands[-1])
    return p.stdout.strip()
assert git(root,"rev-parse","HEAD")==scope["sha"] and not git(root,"status","--porcelain")
git(dev,"rev-parse","HEAD");git(dev,"status","--porcelain")
git(root,"ls-remote","https://github.com/wwooyy429/Alpha-Quant-Research-Platform-AQRP-.git","refs/heads/main","refs/heads/feature/phase-3-alpha-research","refs/tags/phase2-baseline*","refs/tags/v0.2.0*")
(out/"end-state.json").write_text(json.dumps(dict(timestamp=datetime.now(timezone.utc).isoformat(),commands=commands,review_source_unchanged=True),ensure_ascii=False,indent=2),encoding="utf-8")
# Report consistency and evidence assertions, not implementation tests.
findings=json.loads((out/"findings.json").read_bytes())
assert len(findings)==5 and sum(f["severity"]=="High" for f in findings)==2
math=json.loads((out/"independent-math-results.json").read_bytes());assert math["cases"]==15 and math["passed"]==75 and math["failed"]==0
assert "PLAN BLOCKED" in (out/"GPT-Work-Phase3-G1-d10a55a-Review.md").read_text(encoding="utf-8")
for command in out.glob("*.command.json"):
    assert json.loads(command.read_text(encoding="utf-8-sig"))["exit_code"]==0
manifestpath=out/"REVIEW_EVIDENCE_MANIFEST.json"
entries=[dict(path=p.relative_to(out).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.rglob("*")) if p.is_file() and p!=manifestpath]
manifest=dict(schema="gpt-work-review-evidence/1",executor="GPT Work supplementary reviewer",fixed_sha=scope["sha"],created_utc=datetime.now(timezone.utc).isoformat(),self_excluded=True,files=entries)
manifestpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
for e in entries:assert hashlib.sha256((out/e["path"]).read_bytes()).hexdigest()==e["sha256"]
bundle=out.parent/"GPT-Work-P3-G1-d10a55a-Evidence.zip"
assert not bundle.exists()
with zipfile.ZipFile(bundle,"w",zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.rglob("*")):
        if p.is_file():z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(entries)+1
    for e in entries:assert hashlib.sha256(z.read(e["path"])).hexdigest()==e["sha256"]
receipt=dict(fixed_sha=scope["sha"],verdict="PLAN BLOCKED",manifest=str(manifestpath),manifest_sha256=hashlib.sha256(manifestpath.read_bytes()).hexdigest(),manifest_files=len(entries),bundle=str(bundle),bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bundle_bytes=bundle.stat().st_size,finalization_command=[sys.executable,"-I",str(Path(__file__).resolve())],all_manifest_entries_and_zip_members_rehashed=True,review_source_clean=True)
(out.parent/"GPT-Work-P3-G1-d10a55a-Receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(receipt,ensure_ascii=False,indent=2))

