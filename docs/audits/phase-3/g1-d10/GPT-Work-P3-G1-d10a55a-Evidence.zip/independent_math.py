"""GPT Work arithmetic audit. No AQRP, NumPy or developer-reference import.
Independent routes: pairwise ranks, raw-sum correlation, orthogonal projections,
HAC Toeplitz quadratic form, direct closed-form ordered p adjustments.
Does not write any golden input, source, approval or repository file.
"""
import ast, hashlib, json, sys
from decimal import Decimal as D, getcontext
from fractions import Fraction as Q
from pathlib import Path
getcontext().prec=80
root=Path(sys.argv[1]).resolve(); out=Path(__file__).resolve().parent
path=root/"docs/audits/phase-3/golden_cases.json"
raw=path.read_bytes(); pack=json.loads(raw); cases=pack["cases"]
checks=[]; details=[]
def dec(v):
    v=Q(v);return D(v.numerator)/D(v.denominator)
def check(case,field,actual,expected,exact=True):
    if isinstance(actual,(list,tuple)):
        assert len(actual)==len(expected),(case,field,"length")
        for i,(a,e) in enumerate(zip(actual,expected)):check(case,field+"/"+str(i),a,e,exact)
        return
    if isinstance(actual,bool): ok=actual is expected
    elif exact: ok=Q(actual)==Q(expected)
    else:
        a,e=dec(actual),dec(expected)
        error=abs(a-e);ok=error<=max(D(pack["float_abs_tol"]),D(pack["float_rel_tol"])*abs(e))
    checks.append(dict(case=case,field=field,actual=str(actual),expected=str(expected),comparison="exact" if exact else "max(abs_tol,rel_tol*abs(expected))",ok=ok))
    assert ok,checks[-1]
def expr(s,env=None):
    env=env or {}
    def visit(n):
        if isinstance(n,ast.Expression):return visit(n.body)
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):
            return D(ast.get_source_segment(s,n))
        if isinstance(n,ast.Name) and n.id in env:return dec(env[n.id])
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -visit(n.operand)
        if isinstance(n,ast.BinOp):
            a,b=visit(n.left),visit(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="sqrt" and len(n.args)==1 and not n.keywords:
            return visit(n.args[0]).sqrt()
        raise ValueError(ast.dump(n))
    return visit(ast.parse(s,mode="eval"))
def rank(v):
    return [Q(1)+sum(w<x for w in v)+Q(sum(w==x for w in v)-1,2) for x in v]
def corr(x,y):
    x,y=list(map(Q,x)),list(map(Q,y));n=len(x)
    cross=n*sum(a*b for a,b in zip(x,y))-sum(x)*sum(y)
    xx=n*sum(a*a for a in x)-sum(x)**2;yy=n*sum(b*b for b in y)-sum(y)**2
    assert xx>0 and yy>0
    return dec(cross)/dec(xx*yy).sqrt()
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def quantile(v,p):
    v=sorted(map(Q,v));z=(len(v)-1)*Q(p);a=z.numerator//z.denominator;w=z-a
    return v[a]*(1-w)+v[min(a+1,len(v)-1)]*w
def corrections(p,m):
    assert len(p)==m
    order=sorted(range(m),key=p.__getitem__);s=[p[i] for i in order]
    h=sum(Q(1,k) for k in range(1,m+1))
    ordered={
      "holm":[min(Q(1),max((m-j)*s[j] for j in range(k+1))) for k in range(m)],
      "by":[min(Q(1),min(Q(m,j+1)*h*s[j] for j in range(k,m))) for k in range(m)],
      "bh":[min(Q(1),min(Q(m,j+1)*s[j] for j in range(k,m))) for k in range(m)]}
    result={}
    for method,values in ordered.items():
        restored=[Q(0)]*m
        for i,value in zip(order,values):restored[i]=value
        result[method]=restored
    return result
for c in cases:
    ident=c["id"];d=c["input"];note={}
    if ident in ("P3-PV","P3-PV-ZERO-CURRENT"):
        p=list(map(Q,d["close"]));v=list(map(Q,d["volume"]));L=d["L"]
        prior=v[-L-1:-1];assert len(prior)==L and len(p)>=L+1
        r=(p[-1]-p[-2])/p[-2];surprise=(L*v[-1]-sum(prior))/sum(prior)
        ans=r*surprise
        check(ident,"expected",ans,c["expected"])
        check(ident,"formula",ans,expr(c["formula"]),False)
        note=dict(one_session_return=str(r),volume_surprise=str(surprise),wrong_L_return_product=str(((p[-1]/p[-L-1])-1)*surprise))
    elif ident=="P3-IC":
        x,y=list(map(Q,d["x"])),list(map(Q,d["y"]))
        ans=corr(x,y);sr=corr(rank(x),rank(y))
        check(ident,"expected_formula",ans,expr(c["expected_formula"]),False)
        check(ident,"expected_spearman",sr,c["expected_spearman"],False)
        note=dict(x_sum=str(sum(x)),y_sum=str(sum(y)),cross_centered=str(dot(x,y)-sum(x)*sum(y)/len(x)),pearson=str(ans),rank_y=[str(v) for v in rank(y)])
    elif ident=="P3-TIE":
        rx=rank(d["x"]);check(ident,"expected_ranks",rx,c["expected_ranks"])
        check(ident,"expected_spearman_formula",corr(rx,rank(d["y"])),expr(c["expected_spearman_formula"]),False)
        note=dict(spearman=str(corr(rx,rank(d["y"]))))
    elif ident=="P3-Z-ICIR":
        x=list(map(Q,d["x"]));mx=sum(x)/len(x)
        vx=sum((a-mx)**2 for a in x)/(len(x)-1)
        z=[dec(a-mx)/dec(vx).sqrt() for a in x]
        check(ident,"expected_z_formula",z,[expr(c["expected_z_formula"],{"x":a}) for a in x],False)
        ic=list(map(Q,d["IC"]));mu=sum(ic)/len(ic);var=sum((a-mu)**2 for a in ic)/(len(ic)-1)
        check(ident,"expected_ic_mean",mu,c["expected_ic_mean"])
        check(ident,"expected_ic_sample_std",dec(var).sqrt(),c["expected_ic_sample_std"],False)
        check(ident,"expected_icir",dec(mu)/dec(var).sqrt(),c["expected_icir"],False)
        note=dict(x_variance=str(vx),z=[str(a) for a in z],ic_variance=str(var))
    elif ident=="P3-ROLL":
        x=list(map(Q,d["x"][-d["L"]:]));mu=sum(x)/len(x)
        ans=dict(mean=mu,std_ddof1=dec(sum((a-mu)**2 for a in x)/(len(x)-1)).sqrt(),sum=sum(x),min=min(x),max=max(x),correlation=corr(x,d["y"]),delay1=x[-2],delta1=x[-1]-x[-2],ts_rank=rank(d["ts_rank_input"])[-1]/d["L"])
        for key,value in ans.items():check(ident,"expected/"+key,value,c["expected"][key],key not in ("std_ddof1","correlation"))
    elif ident=="P3-WINSOR":
        lo,hi=[quantile(d["x"],q) for q in d["quantiles"]]
        check(ident,"expected",[min(hi,max(lo,Q(x))) for x in d["x"]],c["expected"])
        note=dict(lower=str(lo),upper=str(hi))
    elif ident=="P3-MAD":
        v=list(map(Q,d["x"]));med=quantile(v,Q(1,2));mad=quantile([abs(a-med) for a in v],Q(1,2))
        check(ident,"median",med,c["median"]);check(ident,"MAD",mad,c["MAD"])
        check(ident,"expected",[min(med+d["k"]*mad,max(med-d["k"]*mad,a)) for a in v],c["expected"])
    elif ident=="P3-OLS":
        X=[list(map(Q,row)) for row in d["X"]];y=list(map(Q,d["y"]))
        columns=list(map(list,zip(*X)));basis=[]
        # Orthogonal projection, not developer's normal-equation elimination.
        for column in columns:
            z=column[:]
            for b in basis:
                scale=dot(b,z)/dot(b,b);z=[a-scale*v for a,v in zip(z,b)]
            assert dot(z,z)>0
            basis.append(z)
        fitted=[Q(0)]*len(y)
        for b in basis:
            a=dot(b,y)/dot(b,b);fitted=[f+a*v for f,v in zip(fitted,b)]
        residual=[a-b for a,b in zip(y,fitted)]
        # Recover coefficients using orthogonal-basis triangular back substitution.
        beta=[Q(0)]*len(columns)
        for j in reversed(range(len(columns))):
            remaining=[a-sum(beta[k]*columns[k][i] for k in range(j+1,len(columns))) for i,a in enumerate(fitted)]
            beta[j]=dot(basis[j],remaining)/dot(basis[j],columns[j])
        check(ident,"expected_beta",beta,c["expected_beta"]);check(ident,"expected_residual",residual,c["expected_residual"])
        assert all(dot(col,residual)==0 for col in columns)
        note=dict(fitted=list(map(str,fitted)),orthogonal_basis=[[str(a) for a in b] for b in basis],X_transpose_e=[str(dot(col,residual)) for col in columns],sse=str(dot(residual,residual)))
    elif ident=="P3-GROUP":
        scores=list(map(Q,d["score"]));labels=list(map(Q,d["labels"]));q=d["q"];n=len(scores)
        bins=[min(q-1,int((r-1)*q/n)) for r in rank(scores)]
        means=[sum(y for y,b in zip(labels,bins) if b==k)/bins.count(k) for k in range(q)]
        check(ident,"expected_group_mean",means,c["expected_group_mean"]);check(ident,"expected_tmb",means[-1]-means[0],c["expected_tmb"])
        check(ident,"expected_monotonicity",corr(rank(means),rank(list(range(q)))),c["expected_monotonicity"],False)
        note=dict(bins=bins)
    elif ident=="P3-HAC":
        v=list(map(Q,d["IC"]));n=len(v);q=d["q"];mu=sum(v)/n;u=[a-mu for a in v]
        assert d["small_sample_correction"]=="none" and 0<=q<n
        W=[[max(Q(0),1-Q(abs(i-j),q+1)) for j in range(n)] for i in range(n)]
        var=sum(u[i]*W[i][j]*u[j] for i in range(n) for j in range(n))/(n*n)
        gam0=dot(u,u)/n;gam1=dot(u[1:],u[:-1])/n
        values=dict(mean=mu,gamma0=gam0,gamma1=gam1,S=var*n,var_mean=var,se=dec(var).sqrt())
        for key,value in values.items():check(ident,"expected/"+key,value,c["expected"][key],key!="se")
        note=dict(kernel=[[str(a) for a in row] for row in W],q0_var=str(dot(u,u)/(n*n)),with_n_over_n_minus_1_correction=str(var*Q(n,n-1)),formal_p="NOT VERIFIED / arithmetic only, n=4 not validated for inference")
    elif ident=="P3-MULTI":
        p=list(map(Q,d["p"]));m=d["m"]
        for method,answer in corrections(p,m).items():check(ident,"expected_"+method,answer,c["expected_"+method])
        check(ident,"bh_requires_dependency_evidence",c["bh_requires_dependency_evidence"],True)
        # Reviewer-added full-family stress case with a failed/not-completed candidate p=1.
        extra=corrections(p+[Q(1)],m+1)
        note=dict(whole_family_with_failed_p1={k:list(map(str,v)) for k,v in extra.items()},harmonic=str(sum(Q(1,k) for k in range(1,m+1))),method="original hypothesis order restored")
    elif ident=="P3-LABEL":
        entry=d["signal_session"]+1;exit_=entry+d["h"]
        check(ident,"expected_entry_session",entry,c["expected_entry_session"]);check(ident,"expected_exit_session",exit_,c["expected_exit_session"])
        check(ident,"expected_return",(Q(d["opens"][exit_])-Q(d["opens"][entry]))/Q(d["opens"][entry]),c["expected_return"])
        note=dict(available_at="not supplied; clock/effective/availability boundary NOT VERIFIED")
    elif ident=="P3-LABEL-ACTION":
        shares=Q(d["split"]);terminal=shares*Q(d["exit_price"]);receivable=shares*Q(d["cash_per_postsplit_share"])
        ret=(terminal+receivable-Q(d["entry_price"]))/Q(d["entry_price"])
        check(ident,"expected_return",ret,c["expected_return"]);check(ident,"formula",ret,expr(c["formula"].split(";")[0]),False)
        note=dict(terminal_stock=str(terminal),dividend_receivable=str(receivable),return_if_no_entitlement=str((terminal-Q(d["entry_price"]))/Q(d["entry_price"])),limitation="No ex/effective/record/pay/available/entry/exit instants in input; 4% conditional on entitlement, boundary NOT VERIFIED")
    elif ident=="P3-PURGE":
        train,held,safe=d["train_label_closed"],d["heldout_protected_closed"],d["safe_train_label_closed"]
        check(ident,"expected_purge",bool(set(range(train[0],train[1]+1))&set(range(held[0],held[1]+1))),c["expected_purge"])
        check(ident,"expected_safe_overlap",bool(set(range(safe[0],safe[1]+1))&set(range(held[0],held[1]+1))),c["expected_safe_overlap"])
        blocked=[held[1]+i for i in range(1,d["embargo_sessions"]+1)]
        check(ident,"expected_post_holdout_blocked_sessions",blocked,c["expected_post_holdout_blocked_sessions"])
    else: raise AssertionError("unhandled case "+ident)
    details.append(dict(id=ident,note=note))
assert len(cases)==15 and len({c["id"] for c in cases})==15
assert Q(pack["float_abs_tol"])==Q(1,10**12) and Q(pack["float_rel_tol"])==Q(1,10**10)
result=dict(executor="GPT Work supplementary reviewer; not Gemini",golden_sha256=hashlib.sha256(raw).hexdigest(),reviewer_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),imports_aqrp=False,imports_developer_reference=False,cases=len(cases),scalar_checks=len(checks),passed=sum(c["ok"] for c in checks),failed=sum(not c["ok"] for c in checks),tolerance={"absolute":pack["float_abs_tol"],"relative":pack["float_rel_tol"],"exact_for":"Fraction/Decimal rationals, indices, boolean state, hashes","floating_rule":"abs(a-e)<=max(atol,rtol*abs(e)); no tolerance relaxation"},checks=checks,details=details,implementation_validation="NOT VERIFIED / no P3 implementation",formal_test_isolation="NOT VERIFIED",formal_financial_approval="NOT VERIFIED")
(out/"independent-math-results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k not in ("checks",)},ensure_ascii=False,indent=2))

