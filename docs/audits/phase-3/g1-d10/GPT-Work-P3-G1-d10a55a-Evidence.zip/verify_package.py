"""Independent byte checks of fixed package, lock, and CI wheels; no AQRP imports."""
import hashlib, io, json, re, sys, zipfile
from pathlib import Path
root=Path(sys.argv[1]).resolve();out=Path(__file__).resolve().parent
package=root/"src/aqrp"
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(o):return sha(json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode())
files=[dict(path=p.relative_to(package).as_posix(),sha256=sha(p.read_bytes())) for p in sorted(package.rglob("*.py"))]
lock=sha((root/"requirements.lock").read_bytes())
manifest=dict(factor_api="1.0.0",data_contract="contracts/1.0.0",dependency_lock_sha256=lock,files=files)
old=digest(manifest);receipt=json.loads((package/"factors/reviewed_code.json").read_bytes())
assert old==receipt["bundle_sha256"]=="51933fe2508e61a25fef53ea73b4210a67cb19d6531e1bf614e206db32a1d62d"
hypothetical=dict(manifest)
hypothetical["files"]=sorted(files+[dict(path="research/__init__.py",sha256=sha(b""))],key=lambda r:r["path"])
assert digest(hypothetical)!=old
lockrows=re.findall(r"^([A-Za-z0-9_.-]+)==([^ ;\\\r\n]+)",(root/"requirements.lock").read_text(),re.M)
assert len(lockrows)==22
ci=json.loads((out/"ci-evidence-verification.json").read_bytes())
checks=[]
for a in ci["artifacts"]:
    env=a["environments"][0]
    assert env["code_commit"]==ci["actual_checkout"] and env["lock_sha256"]==lock and env["dirty"] is False and env["complete"] is True
    assert env["python"].startswith("3.13.16 ")
    with zipfile.ZipFile(out/f'artifact-{a["id"]}.zip') as archive:
        wheelname=a["wheels"][0]["path"]
        with zipfile.ZipFile(io.BytesIO(archive.read(wheelname))) as wheel:
            matched=[]
            for item in files+[dict(path="factors/reviewed_code.json",sha256=sha((package/"factors/reviewed_code.json").read_bytes()))]:
                actual=sha(wheel.read("aqrp/"+item["path"]))
                assert actual==item["sha256"]
                matched.append(dict(path=item["path"],sha256=actual))
            pyfiles={n.removeprefix("aqrp/") for n in wheel.namelist() if n.startswith("aqrp/") and n.endswith(".py")}
            assert pyfiles=={f["path"] for f in files}
    checks.append(dict(artifact_id=a["id"],wheel_sha256=a["wheels"][0]["sha256"],source_files=matched,extra_source_files=[]))
result=dict(package_py_files=len(files),bundle_sha256=old,lock_sha256=lock,locked_packages=lockrows,receipt=receipt,ci_wheels=checks,hypothetical_empty_module_only_in_memory=dict(path="research/__init__.py",new_bundle_sha256=digest(hypothetical),old_bundle_identity_preserved=False),repository_modified=False)
(out/"compatibility-evidence.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(dict(package_py_files=len(files),bundle_sha256=old,lock_sha256=lock,locked_packages=len(lockrows),ci_wheels_checked=len(checks),virtual_new_bundle=digest(hypothetical),repository_modified=False),indent=2))

