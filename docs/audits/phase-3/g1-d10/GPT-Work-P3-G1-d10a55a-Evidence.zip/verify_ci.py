"""Read only GitHub ZIP evidence; never execute contained code."""
import hashlib, json, subprocess, sys, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path(sys.argv[1]).resolve()
meta=json.loads((out/"ci-artifacts-metadata.json").read_bytes());items=[]
for a in meta["artifacts"]:
    zpath=out/f'artifact-{a["id"]}.zip';raw=zpath.read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    assert "sha256:"+digest==a["digest"] and len(raw)==a["size_in_bytes"]
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        names=z.namelist()
        envs=[n for n in names if n.endswith("/environment.json") or n=="environment.json"]
        tests=[n for n in names if n.endswith(".xml")]
        environments=[json.loads(z.read(n)) for n in envs]
        junit=[]
        for n in tests:
            xml=ET.fromstring(z.read(n))
            testcases=xml.findall(".//testcase")
            counts=dict(testcases=len(testcases),failures=sum(len(t.findall("failure")) for t in testcases),errors=sum(len(t.findall("error")) for t in testcases),skips=sum(len(t.findall("skipped")) for t in testcases))
            junit.append(dict(path=n,**counts))
        logs=[n for n in names if n.endswith(".log") and ("pytest" in n or "test" in n)]
        summaries=[]
        for n in logs:
            text=z.read(n).decode("utf-8","replace")
            summaries.extend(dict(file=n,line=l) for l in text.splitlines() if "417 passed" in l)
        wheels=[dict(path=n,sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in names if n.endswith(".whl")]
        filehashes=[dict(path=n,bytes=len(z.read(n)),sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in names if not n.endswith("/")]
        (out/f'artifact-{a["id"]}-members.json').write_text(json.dumps(filehashes,indent=2),encoding="utf-8")
        # Preserve selected decoded originals beside ZIP, without arbitrary extraction.
        for n in tests+envs+logs:
            target=out/f'artifact-{a["id"]}'/n
            if not target.resolve().is_relative_to(out):raise ValueError("unsafe archive path")
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n))
        assert any(j["testcases"]==417 and j["failures"]==j["errors"]==j["skips"]==0 for j in junit)
        items.append(dict(id=a["id"],name=a["name"],bytes=len(raw),sha256=digest,junit=junit,pytest_summary=summaries,wheels=wheels,environments=environments,files=len(filehashes)))
merge=json.loads((out/"ci-merge-commit.json").read_bytes())
p=subprocess.run(["git","-C",str(root),"rev-parse","HEAD^{tree}"],capture_output=True,text=True)
assert p.returncode==0 and p.stdout.strip()==merge["tree"]["sha"]
r=dict(scope="P2 baseline regression CI only, not P3 implementation",run_id=39645351705,head_sha="d10a55a7dd4bc9ca7793ed474bdc1b056916e96e",actual_checkout=merge["sha"],merge_parents=[p["sha"] for p in merge["parents"]],merge_tree=p.stdout.strip(),tree_equal_fixed_review=True,artifacts=items,commands=[dict(argv=p.args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)])
(out/"ci-evidence-verification.json").write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({**{k:v for k,v in r.items() if k not in ("artifacts","commands")},"artifacts":[{k:v for k,v in a.items() if k!="environments"} for a in items]},indent=2))

