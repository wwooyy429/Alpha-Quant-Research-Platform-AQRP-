"""Read-only archival receipt and original release-wheel verification."""
import hashlib,io,json,subprocess,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]).resolve();out=Path(__file__).resolve().parent
p3=root/"docs/audits/phase-3";archive=p3/"g1-d10"
def sha(b):return hashlib.sha256(b).hexdigest()
receipt=json.loads((archive/"RECEIPT.json").read_bytes())
zpath=archive/"GPT-Work-P3-G1-d10a55a-Evidence.zip";zraw=zpath.read_bytes()
assert sha(zraw)==receipt["outer_zip_sha256"]=="09198db18696e972067955a59d92b5058872b9e9f660fc8cd29c471d7a44f607"
checked=[]
with zipfile.ZipFile(io.BytesIO(zraw)) as z:
    assert z.testzip() is None
    manifest_raw=z.read("REVIEW_EVIDENCE_MANIFEST.json")
    assert manifest_raw==(archive/"REVIEW_EVIDENCE_MANIFEST.json").read_bytes()
    manifest=json.loads(manifest_raw);assert len(manifest["files"])==66
    for item in manifest["files"]:
        b=z.read(item["path"]);assert len(b)==item["bytes"] and sha(b)==item["sha256"]
        checked.append(dict(path=item["path"],sha256=sha(b),ok=True))
    original_files=[]
    for item in receipt["original_files"]:
        b=(archive/item["path"]).read_bytes();assert len(b)==item["bytes"] and sha(b)==item["sha256"]
        if item["path"] in z.namelist():assert b==z.read(item["path"])
        original_files.append(dict(path=item["path"],sha256=sha(b),ok=True))
old_unchanged=[]
for name in ("golden_cases.json","reference_arithmetic.py","reference_arithmetic.log"):
    p=subprocess.run(["git","-C",str(root),"show","d10a55a7dd4bc9ca7793ed474bdc1b056916e96e:docs/audits/phase-3/"+name],capture_output=True)
    assert p.returncode==0
    now=(p3/name).read_bytes();assert now==p.stdout
    old_unchanged.append(dict(path=name,sha256=sha(now)))
release=root/"docs/audits/phase-2/publication"
meta=json.loads((release/"VALIDATION.json").read_bytes())
wheel=release/"sdk/wheel/aqrp-0.2.0-py3-none-any.whl"
assert sha(wheel.read_bytes())==meta["wheel_sha256"]=="70b43271ee142b18d5d9d306d452936f8409322fda5e676431f24eb150871c9d"
package=root/"src/aqrp"
with zipfile.ZipFile(wheel) as z:
    wheel_source=[]
    for p in sorted(package.rglob("*.py")):
        b=p.read_bytes();n="aqrp/"+p.relative_to(package).as_posix()
        assert z.read(n)==b
        wheel_source.append(dict(path=n,sha256=sha(b)))
    old_receipt=z.read("aqrp/factors/reviewed_code.json")
    assert old_receipt==(package/"factors/reviewed_code.json").read_bytes()
lock=root/"requirements.lock";assert sha(lock.read_bytes())==meta["lock_sha256"]
r=dict(executor="GPT Work supplementary reviewer",outer_zip_sha256=sha(zraw),original_manifest_members=len(checked),original_manifest_checks=checked,receipt_files=original_files,old_15_inputs_preserved=old_unchanged,original_release_wheel=dict(path=str(wheel),bytes=wheel.stat().st_size,sha256=sha(wheel.read_bytes()),source_files=wheel_source,receipt_sha256=sha(old_receipt),bundle=json.loads(old_receipt)["bundle_sha256"]),original_lock_sha256=sha(lock.read_bytes()),environment_archive="No complete EnvironmentArchiveRef/OS+interpreter installer+22 wheelhouse in the P3 plan. Exact old process routing/replay NOT VERIFIED; G2 implementation evidence required.",original_author_identity="GPT Work supplementary review, not Gemini")
(out/"archive-and-reproduction-evidence.json").write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(dict(outer_zip_sha256=r["outer_zip_sha256"],manifest_members=66,receipt_files=len(original_files),old15_files_unchanged=len(old_unchanged),release_wheel_sha256=sha(wheel.read_bytes()),source_modules=len(wheel_source),lock_sha256=r["original_lock_sha256"],new_reproduction_router="NOT IMPLEMENTED / NOT VERIFIED"),indent=2))

