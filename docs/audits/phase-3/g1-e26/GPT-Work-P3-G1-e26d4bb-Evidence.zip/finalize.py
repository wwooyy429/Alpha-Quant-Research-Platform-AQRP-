"""Final read-only state check, manifest and review evidence ZIP sealing."""
import hashlib,io,json,subprocess,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent;s=json.loads((out/"scope-verification.json").read_bytes());root=Path(s["environment"]["root"])
cmds=[]
def git(*args):
    p=subprocess.run(["git","-C",str(root),*args],capture_output=True,text=True)
    cmds.append(dict(argv=p.args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
    assert p.returncode==0
    return p.stdout.strip()
assert git("rev-parse","HEAD")==s["sha"] and not git("status","--porcelain")
git("ls-remote","https://github.com/wwooyy429/Alpha-Quant-Research-Platform-AQRP-.git","refs/heads/main","refs/heads/feature/phase-3-alpha-research","refs/tags/phase2-baseline*","refs/tags/v0.2.0*")
# Check no extra Python payloads in either CI wheel or the preserved release wheel.
source_set={"aqrp/"+p.relative_to(root/"src/aqrp").as_posix() for p in (root/"src/aqrp").rglob("*.py")}
ci=json.loads((out/"ci-verification.json").read_bytes())
for a in ci["artifacts"]:
    with zipfile.ZipFile(out/f'artifact-{a["id"]}.zip') as z:
        name=next(n for n in z.namelist() if n.endswith(".whl"))
        with zipfile.ZipFile(io.BytesIO(z.read(name))) as w:
            assert {n for n in w.namelist() if n.startswith("aqrp/") and n.endswith(".py")}==source_set
release=root/"docs/audits/phase-2/publication/sdk/wheel/aqrp-0.2.0-py3-none-any.whl"
with zipfile.ZipFile(release) as w:
    assert {n for n in w.namelist() if n.startswith("aqrp/") and n.endswith(".py")}==source_set
(out/"end-state.json").write_text(json.dumps(dict(timestamp=datetime.now(timezone.utc).isoformat(),commands=cmds,review_clone_clean=True,no_extra_python_in_three_wheels=True,head_drift_document="sha-drift.json"),ensure_ascii=False,indent=2),encoding="utf-8")
failed=[]
for p in out.glob("*.command.json"):
    r=json.loads(p.read_text(encoding="utf-8-sig"))
    if r["exit_code"]:failed.append(p.name)
assert failed==["supplemental-independent.command.json"],failed
m=json.loads((out/"independent-supplemental-results.json").read_bytes());assert m["passed"]==146 and m["failed"]==0
prior=json.loads((out/"independent-math-results.json").read_bytes());assert prior["passed"]==75
assert "ff4c546b9a8f6652ff70804055d9435ac08f63b3" in (out/"GPT-Work-Phase3-G1-e26d4bb-Recheck.md").read_text(encoding="utf-8")
manifestpath=out/"REVIEW_EVIDENCE_MANIFEST.json"
def sha(b):return hashlib.sha256(b).hexdigest()
files=[dict(path=p.relative_to(out).as_posix(),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(out.rglob("*")) if p.is_file() and p!=manifestpath]
manifest=dict(schema="gpt-work-supplemental-review-evidence/1",reviewed_sha=s["sha"],verdict="PLAN BLOCKED",executor="GPT Work supplementary review; not Gemini",self_excluded=True,reviewer_failed_attempts_preserved=failed,files=files)
manifestpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
for item in files:assert sha((out/item["path"]).read_bytes())==item["sha256"]
bundle=out.parent/"GPT-Work-P3-G1-e26d4bb-Evidence.zip";assert not bundle.exists()
with zipfile.ZipFile(bundle,"w",zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.rglob("*")):
        if p.is_file():z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for item in files:assert sha(z.read(item["path"]))==item["sha256"]
receipt=dict(reviewed_sha=s["sha"],verdict="PLAN BLOCKED",design_closed=["WORK-P3-003","WORK-P3-004"],open=["WORK-P3-001","WORK-P3-002","WORK-P3-005"],source_clone_clean=True,manifest_files=len(files),manifest_sha256=sha(manifestpath.read_bytes()),bundle=str(bundle),bundle_bytes=bundle.stat().st_size,bundle_sha256=sha(bundle.read_bytes()),finalization_command=[sys.executable,"-I",str(Path(__file__).resolve())],head_drift="ff4c546b9a8f6652ff70804055d9435ac08f63b3 observed during review; NOT REVIEWED",raw_failed_helper_logs_preserved=True)
(out.parent/"GPT-Work-P3-G1-e26d4bb-Receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(receipt,ensure_ascii=False,indent=2))

