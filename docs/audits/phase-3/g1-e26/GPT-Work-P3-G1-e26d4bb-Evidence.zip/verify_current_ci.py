"""Original CI ZIP byte/JUnit/environment/source verification; no execution of contents."""
import hashlib,io,json,subprocess,sys,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(sys.argv[1]).resolve();out=Path(__file__).resolve().parent;pkg=root/"src/aqrp"
def sha(b):return hashlib.sha256(b).hexdigest()
meta=json.loads((out/"ci-artifacts.json").read_bytes());merge=json.loads((out/"ci-merge.json").read_bytes())
tree=subprocess.run(["git","-C",str(root),"rev-parse","HEAD^{tree}"],capture_output=True,text=True)
assert tree.returncode==0 and tree.stdout.strip()==merge["tree"]["sha"]
result=[]
for a in meta["artifacts"]:
    payload=(out/f'artifact-{a["id"]}.zip').read_bytes();assert len(payload)==a["size_in_bytes"] and "sha256:"+sha(payload)==a["digest"]
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        assert z.testzip() is None
        files=[dict(path=n,bytes=len(z.read(n)),sha256=sha(z.read(n))) for n in z.namelist() if not n.endswith("/")]
        jname=next(n for n in z.namelist() if n.endswith("/junit.xml"))
        xml=ET.fromstring(z.read(jname));tests=xml.findall(".//testcase")
        counts=dict(tests=len(tests),failed=sum(bool(t.findall("failure")) for t in tests),errors=sum(bool(t.findall("error")) for t in tests),skipped=sum(bool(t.findall("skipped")) for t in tests))
        assert counts==dict(tests=417,failed=0,errors=0,skipped=0)
        ename=next(n for n in z.namelist() if n.endswith("/environment.json"));env=json.loads(z.read(ename))
        assert env["code_commit"]==merge["sha"] and env["dirty"] is False and env["complete"] is True and env["python"].startswith("3.13.16 ")
        assert env["lock_sha256"]==sha((root/"requirements.lock").read_bytes())
        wname=next(n for n in z.namelist() if n.endswith(".whl"));wheel=z.read(wname)
        with zipfile.ZipFile(io.BytesIO(wheel)) as w:
            source=[]
            for p in sorted(pkg.rglob("*.py")):
                n="aqrp/"+p.relative_to(pkg).as_posix();assert w.read(n)==p.read_bytes();source.append(dict(path=n,sha256=sha(p.read_bytes())))
            assert w.read("aqrp/factors/reviewed_code.json")==(pkg/"factors/reviewed_code.json").read_bytes()
        for name in (jname,ename):
            target=out/f'artifact-{a["id"]}'/name;assert target.resolve().is_relative_to(out);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
        result.append(dict(id=a["id"],name=a["name"],bytes=len(payload),sha256=sha(payload),junit=counts,environment=env,wheel_sha256=sha(wheel),source_files=source,files=files))
r=dict(executor="GPT Work review of CI evidence; actual CI executed by GitHub hosted runners",scope="P2 unchanged baseline only; not P3 implementation",run_id=39653524560,actual_checkout=merge["sha"],fixed_head="e26d4bbfe28262c35396f66daa183771573a988e",merge_tree=merge["tree"]["sha"],tree_equal_fixed_review=True,artifacts=result)
(out/"ci-verification.json").write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(dict(run_id=r["run_id"],actual_checkout=r["actual_checkout"],tree_equal_fixed_review=True,artifacts=[{k:v for k,v in a.items() if k in ("id","name","bytes","sha256","junit","wheel_sha256")} for a in result]),indent=2))

