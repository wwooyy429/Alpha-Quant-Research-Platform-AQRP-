"""Analytical bounded MA(1) counterexample to fixed-lag Bartlett consistency.
Reviewer calculation only; not an AQRP run or a simulation-based claim.
"""
import itertools,json,math,sys
from fractions import Fraction as F
from pathlib import Path
out=Path(__file__).resolve().parent
states=list(itertools.product((-1,1),repeat=4))
xs=[tuple((F(v[k])+F(v[k+1]))/2 for k in range(3)) for v in states]
gamma=[sum(x[2]*x[2-k] for x in xs)/len(xs) for k in range(3)]
assert gamma==[F(1,2),F(1,4),F(0)]
true_lrv=gamma[0]+2*gamma[1]
checks=[]
for h,q in ((1,5),(5,5),(10,9),(20,19)):
    limit=gamma[0]+2*(1-F(1,q+1))*gamma[1]
    checks.append(dict(h=h,q=q,n_gate=max(252,20*(q+1)),true_long_run_variance=str(true_lrv),fixed_q_estimator_probability_limit=str(limit),relative_underestimate=str((true_lrv-limit)/true_lrv),se_ratio=math.sqrt(float(limit/true_lrv))))
assert checks[0]["fixed_q_estimator_probability_limit"]=="11/12"
r=dict(executor="GPT Work supplementary reviewer",scope="Analytical evidence for continuing WORK-P3-005; no production formal gate executed",process="x_t=(epsilon_t+epsilon_(t-1))/2; iid Rademacher epsilon; x in {-1,0,1}; stationary 1-dependent",construction="Enumerated all 16 combinations of four independent signs to compute population gamma0/1/2 exactly",gamma=list(map(str,gamma)),true_long_run_variance=str(true_lrv),fixed_h_profiles=checks,limitation="This does not claim the proposed unapproved FORMAL_INFERENCE actually admitted the process. It shows stationarity/short memory/CLT plus min_n and coverage of nonzero lag do not alone justify fixed-q Bartlett p values; acceptable taper bias must be substantively defined or the formal profile changed.")
(out/"fixed-bandwidth-counterexample.json").write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(r,ensure_ascii=False,indent=2))

