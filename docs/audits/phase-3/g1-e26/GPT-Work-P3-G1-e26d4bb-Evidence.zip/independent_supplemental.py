"""GPT Work independent check of supplemental design fixtures, not AQRP behavior.
No AQRP/developer-reference imports. Decimal Gauss-Legendre integration of
exp(-t*t) with independently calculated pi replaces the author's erf series.
"""
import ast, hashlib, json, math, sys
from datetime import datetime
from decimal import Decimal as D, getcontext
from fractions import Fraction as F
from pathlib import Path
getcontext().prec=90
root=Path(sys.argv[1]).resolve();out=Path(__file__).resolve().parent
raw=(root/"docs/audits/phase-3/supplemental_cases.json").read_bytes()
data=json.loads(raw);default=data["label_defaults"]
checks=[];case_notes=[];tails=[]
def T(s):return datetime.fromisoformat(s.replace("Z","+00:00"))
def dec(x):
    f=F(x);return D(f.numerator)/D(f.denominator)
def check(cid,field,a,e,kind="exact"):
    if isinstance(a,(tuple,list)):
        assert len(a)==len(e),(cid,field,"length")
        for k,(aa,ee) in enumerate(zip(a,e)):check(cid,field+"/"+str(k),aa,ee,kind)
        return
    if a is None or isinstance(a,(str,bool,datetime)):
        ok=a==e and (not isinstance(a,bool) or isinstance(e,bool))
    elif kind=="float":
        err=abs(dec(a)-dec(e));ok=err<=max(D(data["float_abs_tol"]),D(data["float_rel_tol"])*abs(dec(e)))
    else:ok=F(a)==F(e)
    checks.append(dict(case=cid,field=field,actual=str(a),expected=str(e),comparison=kind,pass_=ok))
    assert ok,checks[-1]
def atan_recip(k):
    x=D(1)/k;term=x;total=term;n=1
    while abs(term)>D("1e-88"):
        term*=-(x*x);total+=term/(2*n+1);n+=1
    return total
PI=16*atan_recip(5)-4*atan_recip(239)
def legendre(n,x):
    a,b=D(1),x
    if n==0:return a,D(0)
    for k in range(2,n+1):a,b=b,((2*k-1)*x*b-(k-1)*a)/k
    return b,n*(x*b-a)/(x*x-1)
nodes={}
def gauss_nodes(n):
    if n in nodes:return nodes[n]
    result=[]
    for k in range(1,n+1):
        x=D(str(math.cos(math.pi*(k-0.25)/(n+0.5))))
        for _ in range(30):
            p,dp=legendre(n,x);dx=p/dp;x-=dx
            if abs(dx)<D("1e-86"):break
        p,dp=legendre(n,x);assert abs(p)<D("1e-80")
        result.append((x,2/((1-x*x)*dp*dp)))
    nodes[n]=result;return result
def tail_integral(x,n):
    area=x/2*sum(w*(-((x/2*(node+1))**2)).exp() for node,w in gauss_nodes(n))
    return 1-2*area/PI.sqrt()
def erfc_hp(x):
    a=tail_integral(x,32);b=tail_integral(x,64)
    assert abs(a-b)<D("1e-45"),(a,b)
    tails.append(dict(argument=str(x),gauss32=str(a),gauss64=str(b),difference=str(abs(a-b))))
    return b
def formula(s):
    def visit(n):
        if isinstance(n,ast.Expression):return visit(n.body)
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return D(ast.get_source_segment(s,n))
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -visit(n.operand)
        if isinstance(n,ast.BinOp):
            a,b=visit(n.left),visit(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        if isinstance(n,ast.Call) and len(n.args)==1 and not n.keywords and isinstance(n.func,ast.Name):
            x=visit(n.args[0])
            if n.func.id=="sqrt":return x.sqrt()
            if n.func.id=="erfc":return erfc_hp(x)
        raise ValueError(ast.dump(n))
    return visit(ast.parse(s,mode="eval"))
def ranks(v):return [F(1)+sum(y<x for y in v)+F(sum(y==x for y in v)-1,2) for x in v]
def correlation(x,y):
    x=list(map(F,x));y=list(map(F,y));n=len(x)
    cross=n*sum(a*b for a,b in zip(x,y))-sum(x)*sum(y)
    xx=n*sum(a*a for a in x)-sum(x)**2;yy=n*sum(b*b for b in y)-sum(y)**2
    return dec(cross)/dec(xx*yy).sqrt()
def sample_z(v):
    v=list(map(F,v));m=sum(v)/len(v);var=sum((x-m)**2 for x in v)/(len(v)-1)
    return [dec(x-m)/dec(var).sqrt() for x in v]
entry,exit_=T(default["entry_at"]),T(default["exit_at"])
calendar=default["calendar_sessions"]
opens=[T(s["open_at"]) for s in calendar]
assert opens[1]==entry and opens[1+default["h"]]==exit_ and T(calendar[0]["close_at"])<T(default["decision_time"])<entry
def action_replay(entry_price,exit_price,events):
    # Event ordering: split, dividend, entry, exit. All symbols are synthetic.
    schedule=[(entry,2,"entry",F(1)),(exit_,3,"exit",F(exit_price))]
    schedule+=events
    qty=F(0);credit=F(0);terminal=None;sold=None;history=[]
    splits=[(t,v) for t,_,typ,v in events if typ=="split"]
    for t,priority,typ,v in sorted(schedule,key=lambda r:(r[0],r[1])):
        if t>exit_:continue
        if typ=="split":qty*=v
        elif typ=="dividend":
            prior_closes=[T(s["close_at"]) for s in calendar if T(s["close_at"])<t]
            assert prior_closes
            anchor=max(prior_closes)
            ratio=F(1)
            for st,sv in splits:
                if anchor<st<=t:ratio*=sv
            credit+=qty*v/ratio
        elif typ=="entry":qty=F(1)
        elif typ=="exit":sold=qty;terminal=qty*v;qty=F(0)
        history.append(dict(time=t.isoformat(),event=typ,qty=str(qty),credit=str(credit)))
    return sold,credit,(terminal+credit)/F(entry_price)-1,history
for c in data["label_cases"]:
    cid=c["id"];e=c["expected"];cutoff=T(c.get("evaluation_cutoff",default["evaluation_cutoff"]))
    assert T(default["actions_complete_through"])>=exit_
    deps=[T(default["entry_bar_available_at"]),T(default["exit_bar_available_at"]),T(c.get("coverage_available_at",default["coverage_available_at"]))]
    div=F(c.get("dividend_per_old_share",0));events=[]
    if c.get("action_available_at"):deps.append(T(c["action_available_at"]))
    if c.get("revision_available_at") and T(c["revision_available_at"])<=cutoff:
        div=F(c["revised_dividend_per_old_share"]);deps.append(T(c["revision_available_at"]))
    eventual=max(deps)
    if eventual>cutoff:
        for field in ("shares","credit","return","label_available_at"):check(cid,field,None,e[field])
        check(cid,"status","NOT_YET_AVAILABLE",e["status"])
        check(cid,"eventual_label_available_at_oracle_only",eventual,T(e["eventual_label_available_at_oracle_only"]))
        case_notes.append(dict(id=cid,information_at_cutoff="null; future timestamp only oracle"));continue
    if c["action_at"]:
        at=T(c["action_at"]);events=[(at,0,"split",F(c.get("split",1))),(at,1,"dividend",div)]
    shares,credit,ret,history=action_replay(c["entry_price"],c["exit_price"],events)
    check(cid,"shares",shares,e["shares"]);check(cid,"credit",credit,e["credit"]);check(cid,"return",ret,e["return"])
    check(cid,"label_available_at",eventual,T(e["label_available_at"]))
    case_notes.append(dict(id=cid,history=history,action_visibility="ordinary cases omit action event/availability; arithmetic presumes those dependencies no later than dominating supplied bar/coverage watermark",return_=str(ret)))
for c in data["other_cases"]:
    cid=c["id"];i=c["input"];e=c["expected"];note={}
    if cid=="LABEL-ANCHOR-RESET":
        events=[(T(i["split_at"]),0,"split",F(i["split"])),(T(i["dividend_at"]),1,"dividend",F(i["dividend_per_old_share"]))]
        shares,credit,ret,history=action_replay(i["entry_price"],i["exit_price"],events)
        anchor=max(T(s["close_at"]) for s in calendar if T(s["close_at"])<T(i["dividend_at"]))
        assert anchor==T(i["anchor_at"]);ratio=F(1)
        for t,_,typ,value in events:
            if typ=="split" and anchor<t<=T(i["dividend_at"]):ratio*=value
        for key,a in dict(shares=shares,ratio_anchor_to_dividend=ratio,credit=credit,return_=ret).items():check(cid,"return" if key=="return_" else key,a,e["return" if key=="return_" else key])
        check(cid,"label_available_at",max(T(default["entry_bar_available_at"]),T(default["exit_bar_available_at"]),T(default["coverage_available_at"])),T(e["label_available_at"]))
        note=dict(history=history)
    elif cid=="LABEL-BAR-CLOSE-AND-FIT":
        available=max(T(i["exit_bar_event_at"]),T(i["exit_bar_available_at"]))
        check(cid,"visible_at_exit_open",available<=T(i["exit_open_at"]),e["visible_at_exit_open"])
        for part in ("before","equal","after"):check(cid,"fit_"+part,available<=T(i["fit_cutoff_"+part]),e["fit_"+part])
    elif cid=="LABEL-LATE-TRAIN-FIT":check(cid,"fit_allowed",T(i["label_available_at"])<=T(i["fit_cutoff"]),e["fit_allowed"])
    elif cid=="PURGE-INFORMATION-CONTACT":
        a,b=map(T,i["train_information_interval"]);c_,d=map(T,i["heldout_protected_interval"])
        check(cid,"purge",not (b<c_ or d<a),e["purge"])
    elif cid.startswith("COMPOSITE-") and cid!="COMPOSITE-REJECTIONS":
        keep=[k for k,(a,b) in enumerate(zip(i["A"],i["B"])) if a is not None and b is not None]
        A=[F(i["A"][k]) for k in keep];B=[F(i["B"][k]) for k in keep]
        az,bz=sample_z(A),sample_z(B);weights=list(map(F,i["weights"]));dirs=i["directions"]
        scores=[(dec(weights[0])*dirs[0]*a+dec(weights[1])*dirs[1]*b)/dec(sum(weights)) for a,b in zip(az,bz)]
        expected=[formula(x) for x in e["composite_formula"]] if "composite_formula" in e else list(map(F,e["composite"]))
        check(cid,"composite",scores,expected,"float")
        if "kept_indices" in e:
            check(cid,"kept_indices",keep,e["kept_indices"]);check(cid,"excluded_indices",[k for k in range(len(i["A"])) if k not in keep],e["excluded_indices"])
        if "raw_correlation" in e:
            check(cid,"raw_correlation",correlation(A,B),e["raw_correlation"],"float")
            check(cid,"signed_correlation",correlation(A,B)*dirs[0]*dirs[1],e["signed_correlation"],"float")
            check(cid,"raw_spearman",correlation(ranks(A),ranks(B)),e["raw_correlation"],"float")
            check(cid,"scale_invariance",sample_z([b*7 for b in B]),bz,"float")
        note=dict(common_indices=keep,normalization="recomputed on common intersection")
    elif cid=="COMPOSITE-REJECTIONS":
        result=dict(all_zero="INVALID_WEIGHTS" if sum(map(F,i["weights_zero"]))==0 else "OK",one_positive="INSUFFICIENT_COMPONENTS" if sum(w>0 for w in map(F,i["weights_one_positive"]))<2 else "OK",empty="INSUFFICIENT_INTERSECTION" if i["missing_all"] else "OK",missing_thresholds="UNCLASSIFIED" if i["thresholds"] is None else "CLASSIFIED")
        for key,a in result.items():check(cid,key,a,e[key],"specified-state-predicate")
    elif cid=="REDUNDANCY-PREDECLARED":
        flag=F(i["absolute_rho"])>=F(i["tau"]) and i["pair_n"]>=i["min_pair_n"] and i["eligible_days"]>=i["min_days"] and F(i["hit_fraction"])>=F(i["min_fraction"])
        check(cid,"flag",flag,e["flag"]);check(cid,"automatic_weight_change",False,e["automatic_weight_change"],"specified-state-predicate");check(cid,"account_write",False,e["account_write"],"specified-state-predicate")
    elif cid in ("HAC-NONZERO-Q1","HAC-NONZERO-Q2"):
        x=list(map(F,i["IC"]));n=len(x);mu=sum(x)/n;u=[v-mu for v in x];q=i["q"]
        var=sum(u[t]*u[s]*max(F(0),1-F(abs(t-s),q+1)) for t in range(n) for s in range(n))/(n*n)
        gamma=[sum(u[t]*u[t-k] for t in range(k,n))/n for k in range(q+1)]
        check(cid,"mean",mu,e["mean"]);check(cid,"gamma",gamma,e["gamma"]);check(cid,"S",n*var,e["S"]);check(cid,"variance",var,e["variance"])
        se=dec(var).sqrt();z=dec(mu)/se
        check(cid,"se_formula" if "se_formula" in e else "se",se,formula(e["se_formula"]) if "se_formula" in e else F(e["se"]),"float")
        check(cid,"z_formula" if "z_formula" in e else "z",z,formula(e["z_formula"]) if "z_formula" in e else F(e["z"]),"float")
        p=erfc_hp(abs(z)/D(2).sqrt())
        check(cid,"p_formula",p,formula(e["p_formula"]),"float");check(cid,"p_approx",p,D(e["p_approx"]),"float")
        check(cid,"formal_eligible",False,e["formal_eligible"],"specified-mode")
        note=dict(se=str(se),z=str(z),p=str(p),formal="ARITHMETIC_REFERENCE only; no inferential validity asserted")
    elif cid=="HAC-PROFILE-BOUNDARIES":
        q=[max(h-1,5) for h in i["horizons"]];mins=[max(252,20*(v+1)) for v in q]
        check(cid,"lags",q,e["lags"]);check(cid,"minimum_ns",mins,e["minimum_ns"])
        for key,n,threshold in (("h1_n251",251,mins[0]),("h1_n252",252,mins[0]),("h20_n399",399,mins[-1]),("h20_n400",400,mins[-1])):check(cid,key,n>=threshold,e[key])
        note=dict(limitation=e["NOTE"])
    elif cid=="HAC-REJECTION-CONTRACT":
        result=dict(short_lag="LAG_BELOW_OVERLAP" if i["q_overlap_too_short"]<i["h"]-1 else "OK",lag_equal_n="INVALID_HORIZON_OR_LAG" if i["q_equal_n"]>=i["n"] else "OK",missing_session="IRREGULAR_OR_MISSING_IC" if i["contains_missing_session"] else "OK",no_assumptions="ASSUMPTIONS_UNVERIFIED" if i["dependence_assessment_ref"] is None else "OK",no_approval="FORMAL_PROTOCOL_UNAPPROVED" if not i["user_formal_protocol_approved"] else "OK")
        for key,a in result.items():check(cid,key,a,e[key],"specified-state-predicate")
        note=dict(limitation="each fixture predicate checked separately, not a multi-error precedence test of future API")
    elif cid=="MULTI-FAILED-FAMILY":
        ps=list(map(F,i["conservative_adjustment_p"]));m=i["m"];assert len(ps)==m
        check(cid,"failed_mapping",ps[-1],1);assert i["raw_p"][-1] is None
        order=sorted(range(m),key=ps.__getitem__);p=[ps[j] for j in order];H=sum(F(1,j) for j in range(1,m+1))
        for method in ("Holm","BY","BH"):
            if method=="Holm":v=[min(F(1),max((m-j)*p[j] for j in range(k+1))) for k in range(m)]
            else:v=[min(F(1),min(F(m,j+1)*p[j]*(H if method=="BY" else 1) for j in range(k,m))) for k in range(m)]
            restored=[F(0)]*m
            for idx,value in zip(order,v):restored[idx]=value
            check(cid,method,restored,e[method])
        check(cid,"formal_family_approvable",not any(v is None for v in i["raw_p"]),e["formal_family_approvable"])
        check(cid,"bh_dependency_evidence_required",True,e["bh_dependency_evidence_required"],"specified-state-predicate")
    else:raise AssertionError(cid)
    case_notes.append(dict(id=cid,**note))
ids=[c["id"] for c in data["label_cases"]+data["other_cases"]]
assert len(ids)==28 and len(set(ids))==28 and set(ids)=={c["case"] for c in checks}
result=dict(executor="GPT Work supplementary independent review, not Gemini",fixed_sha="e26d4bbfe28262c35396f66daa183771573a988e",input_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),method="event-priority replay + exact Fraction + 90-digit Decimal + Machin pi + 32/64 Gauss-Legendre normal-tail quadrature + Toeplitz HAC + direct ordered multiplicity formulas",imports_aqrp=False,imports_developer_reference=False,cases=28,assertions=len(checks),passed=sum(c["pass_"] for c in checks),failed=sum(not c["pass_"] for c in checks),pi=str(PI),tail_quadrature=tails,checks=checks,case_notes=case_notes,future_api_execution="NOT VERIFIED; predicates are specified-design arithmetic, not P3 production tests",deployment="NOT VERIFIED",financial_approval="UNAPPROVED")
(out/"independent-supplemental-results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({k:result[k] for k in ("executor","fixed_sha","input_sha256","script_sha256","method","cases","assertions","passed","failed","tail_quadrature","future_api_execution")},ensure_ascii=False,indent=2))

