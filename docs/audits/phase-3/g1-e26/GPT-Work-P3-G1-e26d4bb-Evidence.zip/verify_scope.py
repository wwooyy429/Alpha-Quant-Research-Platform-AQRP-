"""GPT Work independent evidence collection; read-only fixed repository."""
import csv, hashlib, json, os, platform, subprocess, sys, sysconfig
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(sys.argv[1]).resolve()
OUT=Path(__file__).resolve().parent
SHA="e26d4bbfe28262c35396f66daa183771573a988e"
BASE="f26255fc40a3080bfa883ad64938f60036a14759"
commands=[]
def git(*args, check=True):
    argv=["git","-C",str(ROOT),*args]
    p=subprocess.run(argv,capture_output=True)
    commands.append(dict(argv=argv,cwd=str(OUT),exit_code=p.returncode,stdout=p.stdout.decode("utf-8","replace"),stderr=p.stderr.decode("utf-8","replace")))
    if check and p.returncode: raise RuntimeError(commands[-1])
    return p.stdout
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def verify_manifest(path, parent):
    data=json.loads(path.read_bytes())
    result=[]
    for item in data["files"]:
        file=parent/item["path"]
        got=sha(file)
        result.append(dict(path=str(file.relative_to(ROOT)),expected=item["sha256"],actual=got,ok=got==item["sha256"],bytes=file.stat().st_size))
    return result
assert git("rev-parse","HEAD").decode().strip()==SHA
assert not git("status","--porcelain").strip()
git("merge-base","--is-ancestor",BASE,SHA)
diff=git("diff","--name-status",BASE,SHA).decode()
business=git("diff","--name-only",BASE,SHA,"--","src","tests","tools",".github","pyproject.toml","requirements.lock","uv.lock","requirements","docs/audits/phase-2").decode()
frozen=verify_manifest(ROOT/"docs/audits/phase-1/implementation/CORE_PRESERVATION.json",ROOT)
p3manifest=verify_manifest(ROOT/"docs/audits/phase-3/FILE_MANIFEST.json",ROOT/"docs/audits/phase-3")
p2manifest=verify_manifest(ROOT/"docs/audits/phase-2/publication/FILE_MANIFEST.json",ROOT/"docs/audits/phase-2/publication")
with (ROOT/"docs/requirements.csv").open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
p3=[r for r in rows if r["phase"]=="3"]
snap=json.loads((ROOT/"docs/audits/phase-3/REQUIREMENTS_SNAPSHOT.json").read_bytes())
trace=json.loads((ROOT/"docs/audits/phase-3/TRACEABILITY_SNAPSHOT.json").read_bytes())
trace_by={r["id"]:r for r in trace["requirements"]}
assert p3==snap["requirements"]
assert {r["id"] for r in p3}==set(trace_by)
assert all(r["dependencies"]==trace_by[r["id"]]["dependencies"] and r["tier"]==trace_by[r["id"]]["tier"] for r in p3)
coverage=[]
for r in p3:
    t=trace_by[r["id"]]
    coverage.append({**r,"p3_interface":t["contract"],"p3_planned_code":t["planned_code"],"p3_planned_test":t["planned_test"],"actual_status":"NOT IMPLEMENTED / plan audit only"})
with (OUT/"canonical-phase3-coverage.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)
git("diff","--unified=3",BASE,SHA,"--","AGENTS.md","README.md","docs/CHANGELOG.md","docs/DECISIONS.md","docs/PROGRESS.md","docs/ROADMAP.md")
remote=git("ls-remote","https://github.com/wwooyy429/Alpha-Quant-Research-Platform-AQRP-.git","refs/heads/main","refs/heads/feature/phase-3-alpha-research","refs/tags/phase0-baseline*","refs/tags/phase1-baseline*","refs/tags/phase2-baseline*","refs/tags/v0.1.1*","refs/tags/v0.2.0*").decode()
merge_tree=git("rev-parse","bb6076f87f616a98feb98287d661830b102ad015^{tree}").decode().strip()
approved_tree=git("rev-parse","e50cd75bf461b6ba02856591d5ef968c622da609^{tree}").decode().strip()
env=dict(timestamp=datetime.now(timezone.utc).isoformat(),executor="GPT Work supplementary reviewer",root=str(ROOT),out=str(OUT),python=sys.version,executable=sys.executable,os=platform.platform(),machine=platform.machine(),pointer_bits=__import__("struct").calcsize("P")*8,py_gil_disabled=sysconfig.get_config_var("Py_GIL_DISABLED"),packages_installed_by_review=False)
result=dict(sha=SHA,base=BASE,environment=env,diff=diff,business_diff=business,canonical_total=len(rows),groups=sorted(set(r["id"].split("-")[0] for r in rows)),phase3_total=len(p3),tiers=dict(Counter(r["tier"] for r in p3)),requirements_sha256=sha(ROOT/"docs/requirements.csv"),lock_files=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in ROOT.rglob("*requirements.lock") if ".git" not in p.parts],frozen_assets=frozen,p3_manifest=p3manifest,p2_publication_manifest=p2manifest,remote_refs=remote,merge_tree=merge_tree,approved_tree=approved_tree)
(OUT/"scope-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
(OUT/"git-commands.json").write_text(json.dumps(commands,ensure_ascii=False,indent=2),encoding="utf-8")
git("archive","--format=zip","--output="+str(OUT/"fixed-source.zip"),SHA)
(OUT/"git-commands.json").write_text(json.dumps(commands,ensure_ascii=False,indent=2),encoding="utf-8")
assert len(rows)==106 and len(result["groups"])==16 and len(p3)==26
assert not business and len(frozen)==50 and all(r["ok"] for r in frozen+p3manifest+p2manifest)
assert merge_tree==approved_tree
print(json.dumps(dict(sha=SHA,base=BASE,canonical_total=len(rows),groups=len(result["groups"]),phase3=len(p3),tiers=result["tiers"],frozen=len(frozen),p3_manifest=len(p3manifest),p2_manifest=len(p2manifest),business_unchanged=not business,requirements_sha256=result["requirements_sha256"],source_zip_sha256=sha(OUT/"fixed-source.zip"),environment=env),ensure_ascii=False,indent=2))

